<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//load model
		$this->load->model('billing_model');
         $this->load->library('cart');
                 
         $this->load->library('session');
	}
	
	  
    public function login()
	{	
		$this->load->view('header');
		$this->load->view('login');
		$this->load->view('footer');
	}
	public function logout()
	{
		 
		$userdata = array(
					'logged_in'  => FALSE,
					'logged_user'     => ""
		);			
		$this->session->set_userdata($userdata);
		$this->load->view('header');
		$this->load->view('login');
		$this->load->view('footer');
	}
	public function auth()
	{
		$data = array();    
		$email =  $_POST['email'] ;
		$password =  $_POST['password'] ;
		if($email=='demo@timeslide.biz' && $password=='demo'){
			
			$userdata = array(
					'logged_in'  => TRUE,
					'logged_user'     => "Demo"
			);			
			$this->session->set_userdata($userdata);			
			redirect('shopping/products');
		}else{
			$userdata = array(
					'logged_in'  => FALSE,
					'logged_user'     => ""
			);			
			$this->session->set_userdata($userdata);	
			redirect('user/login');
		}
		
		
	}
 
}