<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class App extends CI_Controller {

	public $default_agents = "10";
	public $default_areatype = "1";
	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_model');
		$this->load->model('client_model');
		$this->load->model('callcenter_model');
		$this->load->model('history_model');
		$this->load->model('webservice_model');
		$this->load->library('session');
		 
	}
	
	 
	public function index()
	{
		redirect('app/dashboard');
	}
    public function login()
	{	
    	/*
		$userdata = array(
				'logged_in'  => FALSE,
				'logged_user'     => "",
				'user_level' => "",
				'client_id' => ""
		);
		$this->session->set_userdata($userdata);
		*/
		$this->session->sess_destroy();
		
		$this->load->view('header');
		$this->load->view('login');
		$this->load->view('footer');
	}
	
	public function checkLoggedIn(){
		
		if($this->session->userdata('logged_in') != TRUE){
			redirect('app/login');
			//echo $this->session->userdata('logged_in');
		}
		
	} 
	public function checkNormalUser(){
	
		if($this->session->userdata('user_level') != 2){
			redirect('app/accessdenied');
		}
	
	}
	public function checkAdminUser(){
	
		if($this->session->userdata('user_level') != 1){
			redirect('app/accessdenied');
		}
	
	}
	public function auth()
	{
		//$this->session->sess_destroy();
		// user_level=2 means normal user and 1 means admin user
		$userlevel = 2;
		$client_id = null;
		if(!empty($_POST) && isset($_POST['username']) && isset($_POST['password'])){
			 $userdata = $this->user_model->getUser($_POST['username'] ,$_POST['password']);
		//	 print_r($userdata); 
			 $validuser = false; 
			 if(!empty($userdata)){
			 		$userlevel = $userdata[0]['user_level'];
			 		$client_id = $userdata[0]['client_id'];
			 	    $validuser= true;
			 	}
			 if($validuser){
			//if($_POST['username'] == 'admin' && $_POST['password']){
				$userdata = array(
						'logged_in'  => TRUE,
						'logged_user'     => $_POST['username'],
						'user_level' =>$userlevel,
						'client_id' =>$client_id
				);
				$this->session->set_userdata($userdata);	
				if($userlevel==1){
					redirect('app/users');
				}else{
					redirect('app/dashboard');
				} 
				
			}else{
				redirect('app/login?reason=unauthorised');
			}
		}else {
			redirect('app/login');
		}
	}
	public function accessdenied()
	{ 
		$this->load->view('header');
		$this->load->view('accessdenied');
		$this->load->view('footer');
	}
	public function dashboard()
	{ 
		$this->checkLoggedIn();
		$this->load->view('header');
		$users =  $this->user_model->getUserByUserName($this->session->userdata('logged_user'));
		$data['name'] = $users[0]['first_name'].','.$users[0]['surname'];
		$data['callcenters'] = $this->callcenter_model->getClientCallcenters($this->session->userdata('client_id'));
		 
		$date = new DateTime();
		$current_date= date_format($date, 'Y-m');
		date_modify($date, '-1 month');
		$last_date= date_format($date, 'Y-m');
		date_modify($date, '-1 month');
		$month_ago_date= date_format($date, 'Y-m');
		date_modify($date, '-1 month');
		$two_months_ago_date= date_format($date, 'Y-m');
		 
		$data['usage'] = array(
				$current_date => $this->history_model->getUsage($this->session->userdata('client_id'),$current_date)[0]['usages'],
				$last_date => $this->history_model->getUsage($this->session->userdata('client_id'),$last_date)[0]['usages'],
				$month_ago_date => $this->history_model->getUsage($this->session->userdata('client_id'),$month_ago_date)[0]['usages'],
				$two_months_ago_date => $this->history_model->getUsage($this->session->userdata('client_id'),$two_months_ago_date)[0]['usages']
		);
		$data['activecampaigns'] = $this->history_model->getActivecampaigns($this->session->userdata('client_id'))[0]['cnt'];
		$data['monthcampaigns'] = $this->history_model->getMonthcampaigns($this->session->userdata('client_id'),$current_date)[0]['cnt'];
		$this->load->view('dashboard',$data);
		
		$this->load->view('footer');
	} 
	public function selectprovinces()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$data['callcenter'] = $this->input->post('callcenter');
		$data['agents'] = $this->input->post('agents')!=null ?$this->input->post('agents'):$this->default_agents;
		$data['areatype'] ="3"; 
		$data['selectedprovince'] = $this->input->post('selectedprovince');
		$this->load->view('select-provinces',$data);
		$this->load->view('footer');
	}
	public function summary()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('summary');
		$this->load->view('footer');
	}
	public function otp()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$users =  $this->user_model->getUserByUserName($this->session->userdata('logged_user'));
		$mobile=$users[0]['contact'];
		
		$current_date = new DateTime();
		$date= date_format($current_date, 'Y-m-d+H:i:s');
		
		$otp= mt_rand(100000,999999);		
		$generatedotp = $this->webservice_model->sendotp($mobile,$otp,$date);
		
		
		
		 $to_replace = substr($mobile, 3,strlen($mobile)-6);
		 $to_replacewith= '';
		 for($i=0;$i<strlen($mobile)-6;$i++){
		 	$to_replacewith.="*";
		 }
		 
		 $newmobile= str_replace($to_replace,$to_replacewith, $mobile);
		 $data['mobile'] = $newmobile;
		
		$data['generatedotp'] = md5($otp);
		$data['date'] =  $date;
		$data['otp'] =  $otp;
		$data['callcenter'] = $this->input->post('callcenter');
		$data['agents'] = $this->input->post('agents');
		$data['areatype'] = $this->input->post('areatype');
		$data['selectedprovince'] = $this->input->post('selectedprovince');
		$data['mapradius'] = $this->input->post('mapradius');
		$data['maplangitude'] = $this->input->post('maplangitude');
		$data['maplatitude'] = $this->input->post('maplatitude');
		$data['geocomplete'] = $this->input->post('geocomplete');
		$this->load->view('otp',$data);
		$this->load->view('footer');
	}
	
	public function location()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$data['callcenter'] = $this->input->post('callcenter');
		$data['areatype'] = '2';
		$data['agents'] = $this->input->post('agents')!=null ?$this->input->post('agents'):$this->default_agents;
		$data['geocomplete'] = $this->input->post('geocomplete')!=null ?$this->input->post('geocomplete'):'';
		$data['mapradius'] = $this->input->post('mapradius')!=null ?$this->input->post('mapradius'):'5';
		$this->load->view('specific-location',$data);
		$this->load->view('footer');
	}
	public function numberofagents()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		
		$data['callcenter'] = $this->input->post('callcenter')!=null ?$this->input->post('callcenter'):'';
		$data['agents'] = $this->input->post('agents')!=null ?$this->input->post('agents'):$this->default_agents;
		$this->load->view('numberofagents',$data);
		$this->load->view('footer');
	}
	public function selecttarget()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$data['callcenter'] = $this->input->post('callcenter')!=null ?$this->input->post('callcenter'):'';
		$data['agents'] = $this->input->post('agents');
		$data['areatype'] = $this->input->post('areatype')!=null ?$this->input->post('areatype'):$this->default_areatype;
		$this->load->view('select-target',$data);
		$this->load->view('footer');
	}
	public function newcampaign()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$data['callcenters'] = $this->callcenter_model->getClientCallcenters($this->session->userdata('client_id'));
		$data['callcenter'] = $this->input->post('callcenter')!=null ?$this->input->post('callcenter'):'';
		$this->load->view('select-data',$data);
		$this->load->view('footer');
	}
	public function createcampaign(){
		
		$pin = $this->input->post('pin')!=null ?$this->input->post('pin'):"";
		$generatedotp = $this->input->post('generatedotp')!=null ?$this->input->post('generatedotp'):"";
		if($generatedotp==md5($pin)){
			$areatype = $this->input->post('areatype')!=null ?$this->input->post('areatype'):0;
			$clientid = $this->session->userdata('client_id');
			$callcenterid = $this->input->post('callcenter')!=null ?$this->input->post('callcenter'):0;
			$totalagents = $this->input->post('agents')!=null ?$this->input->post('agents'):0;
			$leadstotal = $this->input->post('leadstotal')!=null ?$this->input->post('leadstotal'):0;
			$mapradius = $this->input->post('mapradius')!=null ?$this->input->post('mapradius'):0;
			$maplangitude = $this->input->post('maplangitude')!=null ?$this->input->post('maplangitude'):0;
			$maplatitude = $this->input->post('maplatitude')!=null ?$this->input->post('maplatitude'):0;
			$selectedprovince = $this->input->post('selectedprovince')!=null ?$this->input->post('selectedprovince'):0;
			if($areatype==1){
				$data = array(
						'call' =>'create',
						'areatype'=>1,
						'client_id'=>$clientid,
						'callcenter_id'=>$callcenterid,
						'leads_total'=>$leadstotal,
					    'total_agents'=>$totalagents
				);
			}else if($areatype==2){
				$data = array(
						'call' =>'create',
						'areatype'=>2,
						'client_id'=>$clientid,
						'callcenter_id'=>$callcenterid,
						'leads_total'=>$leadstotal,
						'total_agents'=>$totalagents,
						'map_radius'=>$mapradius,
						'map_lat'=>$maplatitude,
						'map_lag'=>$maplangitude
				);
			}else if($areatype==3){
				$data = array(
						'call' =>'create',
						'areatype'=>3,
						'client_id'=>$clientid,
						'callcenter_id'=>$callcenterid,
						'leads_total'=>$leadstotal,
						'total_agents'=>$totalagents,
						'selected_provinces'=>$selectedprovince
				);
			}
			
			//print_r($data);
			$output = $this->webservice_model->createcampaign($data);
			if(!empty($output)){
				$return = array("success"=>true,"data"=>$output);
			}else{
				$return = array("success"=>false,"message"=>"Something went wrong!");
			}
		}else{
			$return = array("success"=>false,"message"=>"Pin is not matching with OTP.");
		}
		echo json_encode($return);
		 
	}
	
	public function history()
	{
		$this->checkLoggedIn();
		$this->checkNormalUser();
		$this->load->view('header');
		print_r ($this->session->userdata('client_id')); 
		$data['billingrate'] = $this->client_model->getClientByID( $this->session->userdata('client_id'))[0]['per_sec_billing_rate'];
		$data['records'] = $this->history_model->getClientCampaignHistory( $this->session->userdata('client_id'));
		$this->load->view('campaign-history',$data);
		$this->load->view('footer');
	}
	public function historyold()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$page = $this->input->post('page')!=null ?$this->input->post('page'):1;
		$perpage = $this->input->post('perpage')!=null ?$this->input->post('perpage'):5;
		$data['totalrecords'] = $this->history_model->getClientHistoryCount ($this->session->userdata('client_id'))[0]['cnt'];
		$data['records'] = $this->history_model->getClientHistory( $this->session->userdata('client_id'),$page,$perpage);
		$data['page'] = $page;
		$data['perpage'] = $perpage;
		$this->load->view('history',$data);
		$this->load->view('footer');
	}
	public function result1()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('result-1');
		$this->load->view('footer');
	}
	
	public function getCampaignData()
	{
		$calldate = $this->input->post('calldate')!=null ?$this->input->post('calldate'):1;
		$records = $this->history_model->getClientHistoryRecord( $this->session->userdata('client_id'),$calldate);
		$return = array();
		if(!empty($records)){
			$return= array("success"=>true,"data"=>$records[0]);
		}else{
			$return = array("success"=>false);
		}
		 echo json_encode($return);
	}
	public function result2()
	{
		$fields = array();
		$destinationpath='';
		if(isset($_FILES['file']) && isset($_FILES['file']['name']) && !empty($_FILES['file']['name']))  {
			
			$calldateindex =0;
			$phone_numberindex=0;
			$lead_idindex = 0;
			$length_in_secindex =0;
			$campaign_idindex=0;
			$outcomeindex=0;
			$row = 1; 
		 
			if (($handle = fopen($_FILES['file']['tmp_name'], "r")) !== FALSE) {
				while (($data = fgetcsv($handle, 1000, "\t")) !== FALSE) {
					$num = count($data);
					$record = array();
				if($row==1){
					for ($c=0; $c < $num; $c++) {
						
							array_push($fields, $data[$c]);
				    }
							
				}else{
					break;
				}
					$row++;
				}
				fclose($handle);
			}
			
			$folder = 'uploads/';
			$filepath= $_FILES['file']['tmp_name'];
			$filename= $_FILES['file']['name'];
			$destinationpath = $folder.$filename;
			move_uploaded_file($filepath, $destinationpath);
			
		}
		 
		$this->checkLoggedIn();
		$this->load->view('header');
		$data['fields'] = $fields;
		$data['destinationpath']=$destinationpath;
		$this->load->view('result-2',$data);
		$this->load->view('footer');
	}
	public function result3()
	{
		
		$destinationpath= $this->input->post('destinationpath');
		$calldates_field= $this->input->post('calldates');
		$phone_number_field= $this->input->post('phone_number');
		$leadid_field= $this->input->post('lead_id');
		$length_in_sec_field= $this->input->post('length_in_sec');
		$campaignid_field= $this->input->post('campaign_id');
		$length_in_sec_field= $this->input->post('length_in_sec');
		$outcome_field= $this->input->post('outcome');
		
		print_r($_POST); 
		
		if(isset($destinationpath) && isset($destinationpath) && !empty($destinationpath)) {
			$calldateindex =0;
			$phone_numberindex=0;
			$lead_idindex = 0;
			$length_in_secindex =0;
			$campaign_idindex=0;
			$outcomeindex=0;
			$row = 1;
			if (($handle = fopen($destinationpath, "r")) !== FALSE) {
				//$this->history_model->deleteOldRecords($this->session->userdata('client_id'));
				while (($data = fgetcsv($handle, 1000, "\t")) !== FALSE) {
					$num = count($data);
					//echo "<p> $num fields in line $row: <br /></p>\n";
					$record = array();
					for ($c=0; $c < $num; $c++) {
						if($row==1){
							if($data[$c]==$calldates_field){
								$calldateindex = $c;
							}else if($data[$c]==$phone_number_field && $phone_numberindex==0){
								$phone_numberindex = $c;
							}else if($data[$c]== $leadid_field){
								$lead_idindex = $c;
							}else if($data[$c]==$length_in_sec_field){
								$length_in_secindex = $c;
							}else if($data[$c]==$campaignid_field){
								$campaign_idindex = $c;
							}else if($data[$c]== $outcome_field){
								$outcomeindex = $c;
							}
						}else if($row>1){
							$record['client_id'] = $this->session->userdata('client_id');
							if($c==$calldateindex){
								$record['call_date'] = $data[$c];
							}else if($c==$phone_numberindex ){
								$record['phone_number'] = $data[$c];
							}else if($c==$lead_idindex){
								$record['lead_id'] = $data[$c];
							}else if($c==$length_in_secindex){
								$record['length_in_sec'] = !empty( $data[$c])? $data[$c]:0;
							}else if($c==$campaign_idindex){
								$record['campaign_id'] = $data[$c];
							}else if($c==$outcomeindex){
								$record['outcome'] = $data[$c];
							}
						}
							
					}
					if($row>1){
						$result =  $this->history_model->insertOrUpdateRecord($record);
						if($result==FALSE){
							//echo "Issue found with  record :";
							//print_r($record);
						}
					}
						
					$row++;
				}
				fclose($handle);
			}
			//  echo 'Total Records'.$row;
		}
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('result-3');
		$this->load->view('footer');
	}
	
	
	public function result2Old()
	{
		$call_dates = array();
		if(isset($_FILES['file']) && isset($_FILES['file']['name']) && !empty($_FILES['file']['name']))  {
			$calldateindex =0;
			$phone_numberindex=0;
			$lead_idindex = 0;
			$length_in_secindex =0;
			$campaign_idindex=0;
			$outcomeindex=0;
			$row = 1;
			if (($handle = fopen($_FILES['file']['tmp_name'], "r")) !== FALSE) {
				$this->history_model->deleteOldRecords($this->session->userdata('client_id'));
				while (($data = fgetcsv($handle, 1000, "\t")) !== FALSE) {
					$num = count($data);
					//echo "<p> $num fields in line $row: <br /></p>\n";
					$record = array();
					for ($c=0; $c < $num; $c++) {
						if($row==1){
							if($data[$c]=='call_date'){
								$calldateindex = $c;
							}else if($data[$c]=='phone_number' && $phone_numberindex==0){
								$phone_numberindex = $c;
							}else if($data[$c]=='lead_id'){
								$lead_idindex = $c;
							}else if($data[$c]=='length_in_sec'){
								$length_in_secindex = $c;
							}else if($data[$c]=='campaign_id'){
								$campaign_idindex = $c;
							}else if($data[$c]=='status_name'){
								$outcomeindex = $c;
							}			
							//echo $data[$c] ." ";
						}else if($row>1){
							$record['client_id'] = $this->session->userdata('client_id');
							if($c==$calldateindex){
								$record['call_date'] = $data[$c];
								array_push($call_dates, $data[$c]);
							}else if($c==$phone_numberindex ){
								$record['phone_number'] = $data[$c];
							}else if($c==$lead_idindex){
								$record['lead_id'] = $data[$c];
							}else if($c==$length_in_secindex){
								$record['length_in_sec'] = !empty( $data[$c])? $data[$c]:0;
							}else if($c==$campaign_idindex){
								$record['campaign_id'] = $data[$c];
							}else if($c==$outcomeindex){
								$record['outcome'] = $data[$c];
							}
						}
			
					}
					if($row>1){
						$result =  $this->history_model->insertOrUpdateRecord($record);
						if($result==FALSE){
							echo "Issue found with  record :";
							print_r($record);
						}
					}
					
					$row++;
				}
				fclose($handle);
			}
		 //  echo 'Total Records'.$row;
		}
		$this->checkLoggedIn();
		$this->load->view('header');
		$data['call_dates'] = $call_dates;
		$this->load->view('result-2',$data);
		$this->load->view('footer');
	}
	public function result3Old()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('result-3');
		$this->load->view('footer');
	}
	
	public function complete()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('complete');
		$this->load->view('footer');
	}
	public function helps()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('complete');
		$this->load->view('footer');
	}
	public function users()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		$data['records'] = $this->user_model->getUsers();
		
		$this->load->view('header');		
		$this->load->view('users',$data);
		$this->load->view('footer');
	}
	public function adduser()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		$data['clients'] = $this->client_model->getClients();
		$data['callcenters'] = $this->callcenter_model->getCallcenter();
		$this->load->view('header');
		$this->load->view('adduser',$data);
		$this->load->view('footer');
	}
	public function edituser()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		
		$array =  $this->user_model->getUserByID($_GET['id']);
		if(!empty($array)){
			$data['record'] = $this->user_model->getUserByID($_GET['id'])[0];
			$data['clients'] = $this->client_model->getClients();
			$data['callcenters'] = $this->callcenter_model->getCallcenter();
			
			$usercallcentersDB = $this->callcenter_model->getUserCallcenters($_GET['id']);
			$tempcallcenters= array();
			foreach ($usercallcentersDB as $ccc){
				array_push($tempcallcenters, $ccc['callcenter_id']);
			}
			$data['usercenters'] = $tempcallcenters;
		}
		$this->load->view('header');
		$this->load->view('edituser',$data);
		$this->load->view('footer');
	}
	public function deleteUser()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		$result = $this->user_model->deleteUser($this->input->post('id'));
		$return = array("success"=>$result);
	    echo json_encode($return);
	}
	public function updateuser()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
	    $result =   $this->user_model->updateUser($this->input->post('id'), $this->input->post('password'),$this->input->post('firstname'),$this->input->post('surname'),
				$this->input->post('contact'),$this->input->post('client'),$this->input->post('callcenter'),
	    		$this->input->post('userlevel')
		);
	    redirect('app/users');
		
	}
	public function insertuser()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		ini_set('display_errors', 1);
		error_reporting(E_ALL);
		$array =  $this->user_model->getUserByUserName($this->input->post('username'));
		$return = array();
		if(!empty($array)){
		     $return = array("success"=>false,"message"=>"username aleady exists.");
		}else{
			$result =   $this->user_model->insertUser($this->input->post('username'), $this->input->post('password'),$this->input->post('firstname'),$this->input->post('surname'),
					$this->input->post('contact'),$this->input->post('client'),$this->input->post('callcenter'),
					$this->input->post('userlevel')
					);
		
		}
		
		redirect('app/users');
		
	
	}
	public function clients()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		$data['records'] = $this->client_model->getClients();
		$this->load->view('header');
		$this->load->view('clients',$data);
		$this->load->view('footer');
	}
	public function addclient()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		$this->load->view('header');
		$data['callcenters'] = $this->callcenter_model->getCallcenter();
		$this->load->view('addclient',$data);
		$this->load->view('footer');
	}
	public function editclient()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
	
		$array =  $this->client_model->getClientByID($_GET['id']);
		if(!empty($array)){
			$data['record'] = $this->client_model->getClientByID($_GET['id'])[0];
			$data['callcenters'] = $this->callcenter_model->getCallcenter();
			
			$clientcallcentersDB = $this->callcenter_model->getClientCallcenters($_GET['id']);
			$tempclientcallcenters= array();
			foreach ($clientcallcentersDB as $ccc){
				array_push($tempclientcallcenters, $ccc['callcenter_id']); 
			}
			$data['clientcenters'] = $tempclientcallcenters;
		}
	
		$this->load->view('header');
		$this->load->view('editclient',$data);
		$this->load->view('footer');
	}
	public function updateclient()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		
		 $result =   $this->client_model->updateclient($this->input->post('id'), $this->input->post('clientname'),$this->input->post('callcenter')
		 		,$this->input->post('address'),$this->input->post('billing')

		 );	
		 redirect('app/clients');
		
	
	}
	public function deleteClient()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		$result = $this->client_model->deleteClient($this->input->post('id'));
		$return = array("success"=>$result);
		echo json_encode($return);
	}
	
	public function insertClient()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		$result =   $this->client_model->insertClient($this->input->post('clientname'), $this->input->post('callcenter'),
				$this->input->post('address'),$this->input->post('billing'));
	
	       redirect('app/clients');
	
	}
	
	public function logout()
	{
		
		$userdata = array(
				'logged_in'  => FALSE,
				'logged_user'     => ""
		);
		$this->session->set_userdata($userdata);
		$this->load->view('header');
		$this->load->view('login');
		$this->load->view('footer');
	}
	public function callcenters()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		$data['records'] = $this->callcenter_model->getCallcenter();
		$this->load->view('header');
		$this->load->view('callcenters',$data);
		$this->load->view('footer');
	}
	public function addcallcenter()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		$this->load->view('header');
		$this->load->view('addcallcenter');
		$this->load->view('footer');
	}
	public function insertCallcenter()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		$destinationpath = '';
		if(isset($_FILES['file']) && isset($_FILES['file']['name']) && !empty($_FILES['file']['name']))  {
			$folder = 'uploads/';
			$filepath= $_FILES['file']['tmp_name'];
			$filename= $_FILES['file']['name'];
			$destinationpath = $folder.$filename;
			move_uploaded_file($filepath, $destinationpath);
		}
		
	
		$result =   $this->callcenter_model->insertCallcenter($this->input->post('name'), $this->input->post('description'),
				$this->input->post('url'),$destinationpath,$this->input->post('filedescription'));
	
		 redirect('app/callcenters');
	
	}
	public function editcallcenter()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		$array =  $this->callcenter_model->getCallcenterByID($_GET['id']);
		if(!empty($array)){
			$data['record'] = $this->callcenter_model->getCallcenterByID($_GET['id'])[0];
		}
		$this->load->view('header');
		$this->load->view('editcallcenter',$data);
		$this->load->view('footer');
	}
	public function updateCallcenter()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		$destinationpath = '';
		if(isset($_FILES['file']) && isset($_FILES['file']['name']) && !empty($_FILES['file']['name']))  {
			$folder = 'uploads/';
			$filepath= $_FILES['file']['tmp_name'];
			$filename= $_FILES['file']['name'];
			$destinationpath = $folder.$filename;
			move_uploaded_file($filepath, $destinationpath);
		}
		
	   $result =   $this->callcenter_model->updateCallcenter($this->input->post('id'),$this->input->post('name'), $this->input->post('description'),
				$this->input->post('url'), $destinationpath,$this->input->post('filedescription'));
	
		 redirect('app/callcenters');
		
	}
  public function deleteCallCenter()
	{
		$this->checkLoggedIn();
		$this->checkAdminUser();
		$result = $this->callcenter_model->deleteCallCenter($this->input->post('id'));
		$return = array("success"=>$result);
		echo json_encode($return);
	}
	public function maptest()
	{
		$this->load->view('maptest');
	}
}