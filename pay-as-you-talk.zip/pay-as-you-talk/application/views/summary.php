<script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyBxXmC--vDhhffL8g5uxOLPgRPnNnCJaZA"></script>   
  
<script>
function initialize()
{
  var mapProp = {
      
    center: new google.maps.LatLng(51.508742,-0.120850),
    zoom:9,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  };
   
  var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
}

google.maps.event.addDomListener(window, 'load', initialize);
</script>

    

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">

  
<section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box">
                
                	<div class="col-sm-12">
                    	<div class="h_text">
                        	<h4>Summary</h4>
                            Comfirm your data selection.
                        </div>
                        
                        <div class="h_text">
                        	
                            	<h5 class="pull-left">Data destination : &nbsp;&nbsp;</h5>
                            	<form role="form">
                            <div class="input-group select_box">
                                <select class="form-control">
                                	<option>Family Funeral Callcenter List 108</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
								</select>
                            </div>
                            
                        </form>
                        </div>
                        <div class="row map_part">
                        	<div class="col-sm-5">
                           	  <table width="100%">
                                  <tr>
                                    <td width="50%" height="50" align="right" valign="top">Area(s) </td>
                                    <td width="5%" align="center" valign="top">:</td>
                                    <td align="left" valign="top" bgcolor="#4A4F53" style="padding:10px;">
                                            10 km radius<br>
                                            Central<br>
                                            South Africa
                                    </td>
                                  </tr>
                                  <tr>
                                    <td align="right" valign="top">&nbsp;</td>
                                    <td align="center" valign="top">&nbsp;</td>
                                    <td align="left" valign="top">&nbsp;</td>
                                  </tr>
                                  <tr>
                                    <td align="right" valign="top">Number of agents(s)</td>
                                    <td width="5%" align="center" valign="top">:</td>
                                    <td align="left" valign="top">20</td>
                                  </tr>
                                  <tr>
                                    <td align="right" valign="top">&nbsp;</td>
                                    <td align="center" valign="top">&nbsp;</td>
                                    <td align="left" valign="top">&nbsp;</td>
                                  </tr>
                                  <tr>
                                    <td align="right" valign="top">Total Leads</td>
                                    <td width="5%" align="center" valign="top">:</td>
                                    <td align="left" valign="top">10,000</td>
                                  </tr>
                                  <tr>
                                    <td align="right" valign="top">&nbsp;</td>
                                    <td align="center" valign="top">&nbsp;</td>
                                    <td align="left" valign="top">&nbsp;</td>
                                  </tr>
                              </table>
                          </div>
                          <div class="col-sm-7"><div id="googleMap"></div></div>
                        </div>
                        
                    </div>
                
                
                <div class="row">
                	<div class="power_btn">
                    	<div class="back_btn">
                        	<div class="input-group select_num_box blue_btn">
                            	<span class="input-group-addon"><i class="fa fa-arrow-left" aria-hidden="true"></i></span>
                            	<a href="#">Back</a>
                                 
                            </div>
                        </div>
                        
                        <div class="next_btn">
                        	<div class="input-group select_num_box green_btn">
                            	<a href="#">Next</a>
                            	<span class="input-group-addon"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                            </div>
                        </div>
                        	Powerd by<br>
                            <h6>BASTION & FLOWE</h6>
                            digital integration
                        </div>
                </div>
                </div>
            </div>
        </div>
    </div>
    	
</section>
