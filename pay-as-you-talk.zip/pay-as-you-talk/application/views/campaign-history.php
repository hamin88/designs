<!-- comformation_modal JavaScript -->
 <script type="text/javascript">
 $( document ).ready(function() {
  $('#alert').hide();
 });
 function changePage(page){
     $('#page').val(page);
     $( "#form" ).trigger( "submit" );
 }
 function previousPage(page){
	 if(page>1){
		 $('#page').val(page-1);
		 $( "#form" ).trigger( "submit" );
	 }
    
 }
 function nextPage(page,pages){
	if((page+1)<pages){
		$('#page').val(page+1);
		$( "#form" ).trigger( "submit" );
    }
 }
  function firstPage(){
	 	$('#page').val(1);
	 	$( "#form" ).trigger( "submit" );
   }
  function lastPage(pages){
	 	$('#page').val(pages);
	 	$( "#form" ).trigger( "submit" );
   }
</script>
<div id="activeRecord" style="display: none;"></div>
 <!-- comformation_modal JavaScript -->
    
<div class="modal fade" id="deleteModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body" style="padding:40px 18px;">
           Are You sure want to delete this record?<br><br>
          <button type="button" onclick="deleteconfirm();" class="btn comfirm_btn" data-dismiss="modal">Yes</button>
          <button type="button" class="btn comfirm_btn" data-dismiss="modal">No</button>
        </div>
        
      </div>
      
    </div>
  </div>
  
<section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box dashboard">
                	<div class="col-sm-12">
                    
                    	<div class="h_text">
                        	<h4>History</h4>
                        </div>
                        <div class="h_text">
                            <div class="row">
                          <div class="col-sm-12">
                            <div class="tap_to_scroll tablete">tap to scroll <strong>&raquo;</strong></div>
                            <div class="table-responsive">
               	  			<table class="table table-bordered">
                              <tr bgcolor="#333">
                                <td width="15%" align="left"> Min Campaign date</td>
                                 <td width="15%" align="left">Max Campaign date</td>
                                <td width="40%" align="center">Campaign name</td>
                                <td width="15%" align="center">Length in seconds</td>
                                <td width="15%" align="center">Total amount spent </td>
                              </tr>
                              <?php foreach ($records as $rec){?>
                              <tr>
                               <td align="left"><?php echo date_format(new DateTime($rec['min_call_date']),'Y-m-d H:i:s'); ?></td>
                               <td align="left"><?php echo date_format(new DateTime($rec['max_call_date']),'Y-m-d H:i:s'); ?></td>
                               <td align="center"><?php echo $rec['campaign_id']; ?></td>
                               <td align="center"><?php echo intval($rec['total_sec']) *  floatval($billingrate) ; ?></td>
                               <td align="center"><?php echo $rec['total_amt']; ?></td>
                              </tr>
                              <?php }?>
                            </table>
                            	</div>

              </div>
                            </div>
                            
                        </div>
              </div>
                	
              <form id="form" action="<?php echo base_url();?>app/history" method="POST">
                	<input type="hidden"  id="page" name="page">
              </form>
              <div class="row">
                	<div class="power_btn">
                        	Powerd by<br>
                            <h6>BASTION &amp; FLOWE</h6>
                            digital integration
                        </div>
                </div>
                </div>
            </div>
        </div>
    	
</section>

