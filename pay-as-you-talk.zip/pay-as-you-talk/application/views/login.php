<script type="text/javascript">$( document ).ready(function() {    
	$('#alert').hide();     
	var reason = "<?php echo isset($_GET['reason'])? $_GET['reason']:'' ; ?>";     
	if(reason=='unauthorised'){    	 $('#alertMsg').html('User is unauthorised.');    	
	 $('#alert').show();      
}     
});</script>
<!-- About Section -->
<section class="login-section">
	<div class="container">
		<div class="row">
			<div class="login_box">
				<div class="col-sm-12">
					<div class="login_logo">
						<img src="<?php echo base_url();?>/images/logo.png" alt="">
					</div>
					<div class="login_botom">
						<div id="alert" class="alert alert-success col-sm-10"
							style="margin-top: 0%; width: 100%; text-align: left;">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<div id="alertMsg"></div>
						</div>
						<form role="form" action="<?php echo base_url();?>app/auth"
							method="post">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-user"
									aria-hidden="true"></i></span> <input type="text"
									class="form-control" name="username" id="user_name"
									placeholder="User Name | enter your username">
							</div>

							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"
									aria-hidden="true"></i></span> <input type="password"
									class="form-control" name="password" id="password"
									placeholder="Password | enter your password">
							</div>
							<button type="submit" class="btn btn-default">Login</button>

						</form>

						<div class="reset_btn">
							<a href="#">RESET</a> | <a href="#">NEED HELP</a>
						</div>
					</div>
				</div>


				<div class="row">
					<div class="power_btn">
						Powerd by<br>
						<h6>BASTION & FLOWE</h6>
						digital integration
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
