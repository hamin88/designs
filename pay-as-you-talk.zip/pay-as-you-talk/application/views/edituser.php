<script type="text/javascript">
$( document ).ready(function() {
	$('#alert').hide();
	$('#userlevel').val("<?php echo (isset($record['user_level']) &&  $record['user_level']==1)?"1":"2";?>");

	if($('#userlevel').val()==1){
  	   $('#client').val(null);
  	   $('#client').prop( "disabled", true );
  	   $('#callcenter').val(null);
  	   $('#callcenter').prop( "disabled", true );
     }else{
      	 $('#client').prop( "disabled", false );
      	 $('#callcenter').prop( "disabled", false );
     }
    
	
    function checkRequired(id){
    	var value = $('#'+id).val().trim();
    	if(value.length==0){
    	    return false;
        }
        return true;
       
     }
    function checkSelected(id){
    	var value = $('#'+id).val();
    	if(value==null || value.length==0){
    	    return false;
        }
        return true;
       
     }

    function showMessage(msg){
    	  $('#alertMsg').html(msg);
     }
    $('#close-alert').click(function() {
    	$('#alert').hide();
    });
    $('#userlevel').change(function() {
        if($('#userlevel').val()==1){
     	   $('#client').val(null);
     	   $('#client').prop( "disabled", true );
     	   $('#callcenter').val(null);
     	   $('#callcenter').prop( "disabled", true );
         }else{
         	 $('#client').prop( "disabled", false );
         	 $('#callcenter').prop( "disabled", false );
            }
       });
    $('#save').click(function() {
    	  $('#alert').hide();
    	  if(!checkRequired('password')){
        	  showMessage("Password is required field.");
        	  $('#alert').show();  
          }else if(!checkRequired('firstname')){
        	  showMessage("First name is required field.");
        	  $('#alert').show();  
          }else if(!checkRequired('surname')){
        	  showMessage("Surname is required field.");
        	  $('#alert').show();  
          }else if(!checkRequired('contact')){
        	  showMessage("Contact number is required field.");
        	  $('#alert').show();  
          }else if($('#userlevel').val()==2 && !checkSelected('client')){
        	  showMessage("Client is required field.");
        	  $('#alert').show();  
          }else if($('#userlevel').val()==2 && !checkSelected('callcenter')){
        	  showMessage("Callcenter name is required field.");
        	  $('#alert').show();    
          }
          else if(!checkRequired('userlevel')){
        	  showMessage("user level is required field.");
        	  $('#alert').show();  
          }
          else{
        	  $('#form').submit();
        	   
          }
          
        
     });
});
</script>
<section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box dashboard">
                	<div class="col-sm-12">
                    
                    	<div class="h_text">
                        	<h4>Edit User Details</h4>
                        </div>
                          
                        <div class="h_text">
                                     
                            <div class="row">
                             
                             <div id="alert" class="alert alert-success col-sm-10" style="margin-top: 0%; width:100%; text-align: left;">
                                         <a id="close-alert" href="javascript:void(0);" class="close"  aria-label="close">&times;</a>
                                         <div id="alertMsg"></div>
                               </div>
                               
                            	<div class="col-sm-12">
                            	
                            	
                            	
                                	<div class="col-sm-10">
  
                                    	<div class="admin_table">
                                    	<form class="form-horizontal"  method="POST" action="updateuser" role="form" id="form">
                                    		
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="username">Username</label>
                                          <div class="col-sm-8 border_left">
                                            <input type="hidden" class="form-control" id="id" name="id"  value="<?php echo isset($record['id'])?$record['id']:'0'; ?>">
                                            <input type="text" class="form-control" id="username" name="username"  placeholder="Username" value="<?php echo isset($record['username'])?$record['username']:''; ?>"
                                            readonly= "readonly">
                                          </div>
                                        </div>
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="username">Password</label>
                                          <div class="col-sm-8 border_left">
                                            <input type="password" class="form-control" id="password" name="password" placeholder="Password" value="<?php echo   $record['password'] ; ?> " >
                                          </div>
                                        </div>
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="firstname">First name</label>
                                          <div class="col-sm-8 border_left">          
                                            <input type="text" class="form-control" id="firstname" name="firstname" placeholder="First name"
                                            value="<?php echo isset($record['first_name'])?$record['first_name']:'' ; ?>" >
                                          </div>
                                        </div>
                                        
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="surname">Surname</label>
                                          <div class="col-sm-8 border_left">          
                                            <input type="text" class="form-control" id="surname" name="surname" placeholder="Surname"
                                            value="<?php echo isset($record['surname'])?$record['surname']:''; ?>">
                                          </div>
                                        </div>
                                        
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="contact">Contact number</label>
                                          <div class="col-sm-8 border_left">          
                                            <input type="text" class="form-control" id="contact" name="contact" placeholder="Contact number"
                                            value="<?php echo isset($record['contact'])?$record['contact']:''; ?>">
                                          </div>
                                        </div>
                                        
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="linktoclient">Link to client</label>
                                          <div class="col-sm-8 border_left">          
                                             <select id="client" name="client" class="form-control">
                                            <?php foreach ($clients as $client ) {?>
                                             <option value="<?php echo  $client['id'] ;?>"><?php echo  $client['client_name'] ;?></option> 
                                             <?php }?>
                                            </select>   
                                        </div>
                                        </div>
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="linktocallcenters">Link to client call centers</label>
                                          <div class="col-sm-8 border_left">          
                                             <select id="callcenter" name="callcenter[]" class="form-control" multiple="multiple">
                                            <?php 
                                            foreach ($callcenters as $callcenter ) { 
                                             if(in_array($callcenter['id'],$usercenters)) {
                                                
                                             	?>
                                               <option value="<?php echo  $callcenter['id'] ;?>" selected="selected"><?php echo  $callcenter['name'] ;?></option>
                                               <?php }else {?>
                                             <option value="<?php echo  $callcenter['id'] ;?>"><?php echo  $callcenter['name'] ;?></option> 
                                             <?php } }?>
                                            </select>
                                        </div>
                                         </div>
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="userlevel">User Level</label>
                                          <div class="control-label col-sm-8 border_left">
                                            <select id="userlevel"  name="userlevel" class="form-control">
                                             <option value="2" >Normal</option>
                                             <option value="1" >Admin</option>
                                            </select>          
                                          </div>
                                        </div>
                                        <div class="form-group" style="margin-top:10px">
                                          <div class="col-sm-4 col-sm-offset-8"> 
                                           <div class="col-sm-6"> 
                                           <button id="save" type="button" class="btn btn-default edit_btn">Save </button>
                                          </div>
                                          <div class="col-sm-6">
                                           <a href = "users"  class="btn btn-default edit_btn" style="text-decoration: none;">Cancel</a>
                                          </div>         
                                          
                                          </div>
                                        </div>
                                      </form>
                                      	</div>
                                  </div>
                                </div>
                                
                             </div>
                            
                        </div>
              </div>
                	
                
              <div class="row">
                	<div class="power_btn">
                        	Powerd by<br>
                            <h6>BASTION &amp; FLOWE</h6>
                            digital integration
                        </div>
                </div>
                </div>
            </div>
        </div>
    	
</section>

