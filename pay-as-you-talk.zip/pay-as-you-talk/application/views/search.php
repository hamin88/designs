  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="https://jqueryui.com/resources/demos/style.css">
  <script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
  <!-- 1.12.0 -->
  <script type="text/javascript">

  function imageerror(img){
        img.src = '<?php echo base_url();?>images/not_avail.jpg';
    
	}

  function changePage(page){
      $('#page').val(page);
      $( "#searchForm" ).trigger( "submit" );
	}
  
            $(document).ready(function() {
                searchCity();
            });
            function searchCity() {
                $("#city").autocomplete({
                    source: function(request, response) {
                        $.ajax({
                            type: "POST",
                           // contentType: "application/json; charset=utf-8",
                            url: "searchCities?name="+document.getElementById('city').value,
                            dataType: "json",
                            success: function (data) {
                                if (data != null) {
                                    response(data);
                                }
                            },
                            error: function(result) {
                            }
                        });
                    },select: function (event, ui)
                    {
                           //alert(ui.item.value);
                    }
                });
            }
        </script>
 
<div class="ui-widget">
  <label for="tags">Tags: </label>
  <input id="tags">
</div>

 
    <!-- Search Section -->
    <section id="about" class="search-section">
    	<div class="container-fluid">
        	<div class="row">
            	<div class="serch_top clearfix">
            	 <form id="searchForm" action="<?php echo base_url();?>company/search" method="POST">
                	<div class="container">
                	
                	<div class="top_form_list wow fadeInUp ui-widget">
                	<input type="hidden"  id="page" name="page">
                      <input type="text" required placeholder="Select City" name="city" id="city" class="form-control input_bg" 
                      value="<?php echo isset($city)?$city:'' ;?>">
                	</div>
                    <div class="top_form_list wow fadeInUp" data-wow-delay="0.3s">
                      <input type="text"  placeholder="Select Company / Organisation" name="company" id="company" 
                      value="<?php echo isset($company)?$company:'' ;?>" class="form-control input_bg">
                	</div>
                    <div class="top_form_list search_btn wow flipInY"  data-wow-delay="0.8s">
                      <button type="submit" class="submit_btn">Search</button>
                	</div>
                    </div>
                    </form>
            		
            	
                </div>
            </div>
        </div>
    	<div class="container">
			
		<div class="row">

			<div class="col-md-12">
				<div class="col-md-3 col-sm-4 col-xs-12 serch-box">
					<div class="search_list wow fadeInLeft">
                    	<h3><li>Categories</li></h3>
                    	<?php foreach ($categories as $category){?>
                    	<li><a href="<?php echo base_url().'company/category/'.$category['id'].'/'.$category['name'] ; ?>"><?php echo $category['desc'] ; ?></a></li>
                    	<?php }?>
                    	category
                    </div>
                    
                    <div class="recent_list">
                    	<div class="recent_title">Recent Listing</div>
                        <div class="recent_box clearfix wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1000ms">
                        	<div class="recent_img"><img src="<?php echo base_url();?>images/thum_1.jpg" class="img-responsive" alt=""></div>
                            <div class="recent_text">Benedictine Study and Arts Centre</div>
                        </div>
                        
                        <div class="recent_box clearfix wow fadeInUp" data-wow-delay="600ms" data-wow-duration="1000ms">
                        	<div class="recent_img"><img src="<?php echo base_url();?>images/thum_5.jpg" class="img-responsive" alt=""></div>
                            <div class="recent_text">Benedictine Study and Arts Centre</div>
                        </div>
                        
                        <div class="recent_box clearfix wow fadeInUp" data-wow-delay="900ms" data-wow-duration="1000ms">
                        	<div class="recent_img"><img src="<?php echo base_url();?>images/thum_8.jpg" class="img-responsive" alt=""></div>
                            <div class="recent_text">Boost Juice Bar</div>
                        </div>
                    </div>
				</div>
                
                <div class="col-md-9 col-sm-8 col-xs-12 serch-box">
                	
					<div class="search_right_top">
                    <div class="about_title search_part wow slideInDown">PREMIUM BUSINESS LISTINGS</div>
                    	<div id="adv_commerce_4_columns_carousel" class="carousel slide three_shows_one_move commerce_columns_carousel_wrapper" data-ride="carousel" data-interval="2000" data-pause="hover">
			
			<!--========= Wrapper for slides =========-->
			<div class="carousel-inner" role="listbox">

				<!--========= First slide =========-->
                <div class="item active">
                <div class="col-md-4">
                	<div class="thum">
							<div class="thum_img">
								<img src="<?php echo base_url();?>images/thum_1.jpg" alt="slider 01" />
							</div>
							<div style=" background-color:#FFF; padding:15px;">
                            	1
                            </div>
						</div>
                </div>
                </div>
				
				
				<!--========= Second slide =========-->
				<div class="item">
                <div class="col-md-4">
                	<div class="thum">
							<div class="thum_img">
								<img src="<?php echo base_url();?>images/thum_2.jpg" alt="slider 01" />
							</div>
							<div style=" background-color:#FFF; padding:15px;">
                            	2
                            </div>
						</div>
                </div>
                </div>

				<!--========= Third Slide =========-->
				<div class="item">
                <div class="col-md-4">
                	<div class="thum">
							<div class="thum_img">
								<img src="<?php echo base_url();?>images/thum_3.jpg" alt="slider 01" />
							</div>
							<div style=" background-color:#FFF; padding:15px;">
                            	3
                            </div>
						</div>
                </div>
                </div>

				<!--========= Fourth Slide =========-->
				<div class="item">
                <div class="col-md-4">
                	<div class="thum">
							<div class="thum_img">
								<img src="<?php echo base_url();?>images/thum_4.jpg" alt="slider 01" />
							</div>
							<div style=" background-color:#FFF; padding:15px;">
                            	4
                            </div>
						</div>
                </div>
                </div>
				
				<!--========= Fifth Slide =========-->
				<div class="item">
                <div class="col-md-4">
                	<div class="thum">
							<div class="thum_img">
								<img src="<?php echo base_url();?>images/thum_5.jpg" alt="slider 01" />
							</div>
							<div style=" background-color:#FFF; padding:15px;">
                            	5
                            </div>
						</div>
                </div>
                </div>

				<!--========= Sixth Slide =========-->
				<div class="item">
                <div class="col-md-4">
                	<div class="thum">
							<div class="thum_img">
								<img src="<?php echo base_url();?>images/thum_6.jpg" alt="slider 01" />
							</div>
							<div style=" background-color:#FFF; padding:15px;">
                            	6
                            </div>
						</div>
                </div>
                </div>
				
				<!--========= Seventh Slide =========-->
				<div class="item">
                <div class="col-md-4">
                	<div class="thum">
							<div class="thum_img">
								<img src="<?php echo base_url();?>images/thum_7.jpg" alt="slider 01" />
							</div>
							<div style=" background-color:#FFF; padding:15px;">
                            	7
                            </div>
						</div>
                </div>
                </div>
				
				<!--========= Eighth Slide =========-->
				<div class="item">
                <div class="col-md-4">
                	<div class="thum">
							<div class="thum_img">
								<img src="<?php echo base_url();?>images/thum_8.jpg" alt="slider 01" />
							</div>
							<div style=" background-color:#FFF; padding:15px;">
                            	8
                            </div>
						</div>
                </div>
                </div>

			</div>

			<!--======= Navigation Buttons =========-->

			<!--======= Left Button =========-->
			<a class="left nxt_btn adv_left" href="#adv_commerce_4_columns_carousel" role="button" data-slide="prev">
				<span class="fa fa-angle-left commerce_columns_carousel_control_icons" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>

			<!--======= Right Button =========-->
			<a class="right nxt_btn adv_right" href="#adv_commerce_4_columns_carousel" role="button" data-slide="next">
				<span class="fa fa-angle-right commerce_columns_carousel_control_icons" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>

		</div>
                    </div>
                    
                    
                    <div class="search_right_bottom">
                    	<h3>Recently Added</h3>
                    	<?php foreach ($companies as $company){?>
                        <div class="add_box clearfix wow fadeIn" data-wow-delay="600ms" data-wow-duration="1000ms">
                        	<div class="left_img"><img src="<?php echo base_url().$company['image'];?>" class="img-responsive" onerror="imageerror(this)" height="150px"></div>
                            <div class="right_text">
                            	<h4><?php echo $company['name'];?></h4>
                                <div class="address"><?php echo $company['address'];?></div><br>
                                text will come here text will come here text will come here text will come here text will come here text will come here  
                            </div>
                        </div>
                    	<?php }?>
                      <div>
                      <ul class="pagination"> 
                       <?php 
                            $perpage = 2;
                            $mode = $totalrecords%$perpage;
                            if($mode!=0){
                            	$pages = intval($totalrecords/$perpage)+1;
                            }else{
                            	$pages = intval($totalrecords/$perpage);
                            }
                            for($i=1;$i<=$pages; $i++){
                            	if($i==$page){
                            		echo '<li class="active"><a href="javascript:changePage('.$i.')">'.$i.'</a></li>';
                            	}else{
                            		echo '<li><a href="javascript:changePage('.$i.')">'.$i.'</a></li>';
                            	}
                            	
                            }
                       ?> 
                      </ul>
                      </div>
                       	
                         
                    </div>
                    
				</div>

			</div>

		</div>

	</div>
    </section>

    
    <!-- Contact Section -->
    
    <section id="contact" class="contact-section">
      <div class="container">
      	<div class="row">
        	<div class="col-md-12">
            	<div class="footer_top">
                        <div class="footer_logo wow fadeInUp"> <a class="page-scroll" href="#page-top"><img src="<?php echo base_url();?>images/logo.png"  alt=""></a> </div>
                        <div class="social_part">
                          <div class="social_icon"> <a href="#" class="icon icon-mono facebook">facebook</a> <a href="#" class="icon icon-mono twitter">twitter</a> <a href="#" class="icon icon-mono googleplus">google+</a> <a href="#" class="icon icon-mono github">github</a> <a href="#" class="icon icon-mono rss">rss</a> </div>
                          <div class="footer_search_btn wow fadeInRight" >
                            <button id="searchButton" type="submit" class="submit_btn">Search</button>
                          </div>
                        </div>
                      </div>
            </div>
        </div>
      </div>
      
      <footer class="container-fluid footer">
                  <div class="copy"> &copy; TimeSlide Software (OPC) PVT LTD </div>
                </footer>
    </section>
