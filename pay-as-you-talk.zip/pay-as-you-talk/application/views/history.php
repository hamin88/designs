<!-- comformation_modal JavaScript -->
 <script type="text/javascript">
 $( document ).ready(function() {
  $('#alert').hide();
 });
 function changePage(page){
     $('#page').val(page);
     $( "#form" ).trigger( "submit" );
 }
 function previousPage(page){
	 if(page>1){
		 $('#page').val(page-1);
		 $( "#form" ).trigger( "submit" );
	 }
    
 }
 function nextPage(page,pages){
	if((page+1)<pages){
		$('#page').val(page+1);
		$( "#form" ).trigger( "submit" );
    }
 }
  function firstPage(){
	 	$('#page').val(1);
	 	$( "#form" ).trigger( "submit" );
   }
  function lastPage(pages){
	 	$('#page').val(pages);
	 	$( "#form" ).trigger( "submit" );
   }
</script>
<div id="activeRecord" style="display: none;"></div>
 <!-- comformation_modal JavaScript -->
    
<div class="modal fade" id="deleteModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body" style="padding:40px 18px;">
           Are You sure want to delete this record?<br><br>
          <button type="button" onclick="deleteconfirm();" class="btn comfirm_btn" data-dismiss="modal">Yes</button>
          <button type="button" class="btn comfirm_btn" data-dismiss="modal">No</button>
        </div>
        
      </div>
      
    </div>
  </div>
  
<section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box dashboard">
                	<div class="col-sm-12">
                    
                    	<div class="h_text">
                        	<h4>History</h4>
                        </div>
                        <div class="h_text">
                            <div class="row">
                          <div class="col-sm-12">
                            <div class="tap_to_scroll tablete">tap to scroll <strong>&raquo;</strong></div>
                            <div class="table-responsive">
               	  			<table class="table table-bordered">
                              <tr bgcolor="#333">
                                <td width="8%" align="left">Call Date & Time</td>
                                <td width="6%" align="center">Phone Number</td>
                                <td width="15%" align="center">Lead Id </td>
                                <td width="15%" align="center">Legnth in seconds</td>
                                <td width="15%" align="center">Campaign Id</td>
                              </tr>
                              <?php foreach ($records as $rec){?>
                              <tr>
                                <td align="left"><?php echo $rec['call_date']; ?></td>
                                <td><?php echo $rec['phone_number']; ?></td>
                                <td><?php echo $rec['lead_id']; ?></td>
                                 <td><?php echo $rec['length_in_sec']; ?></td>
                                 <td><?php echo $rec['campaign_id']; ?></td>
                              </tr>
                              <?php }?>
                            </table>
                            <ul class="pagination"> 
                       <?php 
                            $mode = $totalrecords%$perpage;
                            if($mode!=0){
                            	$pages = intval($totalrecords/$perpage)+1;
                            }else{
                            	$pages = intval($totalrecords/$perpage);
                            }
                            
                            $start = $page-7;
                            if($start<1){
                            	$start = 1;
                            }
                            $end = $page+7;
                            if($end>$pages){
                            	$end = $pages;
                            }
                            echo '<li><a href="javascript:previousPage('.$page.')">Prev</a></li>';
                            echo '<li><a href="javascript:firstPage()">First</a></li>';
                            for($i=$start;$i<=$end; $i++){
                            	if($i==$page){
                            		echo '<li class="active"><a href="javascript:changePage('.$i.')">'.$i.'</a></li>';
                            	}else{
                            		echo '<li><a href="javascript:changePage('.$i.')">'.$i.'</a></li>';
                            	}
                            	
                            }
                            echo '<li><a href="javascript:lastPage('.$pages.')">Last</a></li>';
                            echo '<li><a href="javascript:nextPage('.$page.','.$pages.')">Next</a></li>';
                       ?> 
                      </ul>
                            	</div>

              </div>
                            </div>
                            
                        </div>
              </div>
                	
              <form id="form" action="<?php echo base_url();?>app/history" method="POST">
                	<input type="hidden"  id="page" name="page">
              </form>
              <div class="row">
                	<div class="power_btn">
                        	Powerd by<br>
                            <h6>BASTION &amp; FLOWE</h6>
                            digital integration
                        </div>
                </div>
                </div>
            </div>
        </div>
    	
</section>

