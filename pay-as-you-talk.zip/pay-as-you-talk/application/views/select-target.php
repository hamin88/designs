<script type="text/javascript">
$( document ).ready(function() {
	$('#areatype').val("<?php echo isset($areatype)? $areatype :'1' ; ?>");
	if($('#areatype').val()=='1'){
		$('input:radio[name=rb]')[0].checked=true;
    }else if($('#areatype').val()=='2'){
		$('input:radio[name=rb]')[1].checked=true;
    } else if($('#areatype').val()=='3'){
		$('input:radio[name=rb]')[2].checked=true;
    }
    $('#next').click(function() {
        if($('input:radio[name=rb]')[0].checked){
        	$("#form").attr('action', 'otp');
        	$('#areatype').val('1');
          }else if($('input:radio[name=rb]')[1].checked){
        	$("#form").attr('action', 'location');
        	$('#areatype').val('2');
          }else if($('input:radio[name=rb]')[2].checked){
        	$("#form").attr('action', 'selectprovinces');
        	$('#areatype').val('3');
          }
    	$('#form').submit();
    });
    $('#back').click(function() {
    	$("#form").attr('action', 'numberofagents');
    	$('#form').submit();
     });
});
</script>
<section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box">
                
                	<div class="col-sm-12">
                    	<div class="h_text">
                    	
                        	<h4>Targeted Area Selection</h4>
                            Select the area you'd like to market to.
                        </div>
                        <div class="h_text clearfix">
                        	<h5>Targeted Area</h5>
                            <form role="form" id="form" method="post" action="location">
                            	<div class="col-sm-6">
                                	<div class="radio">
                                	 <input id="callcenter" name="callcenter" type="hidden" value="<?php echo isset($callcenter)?$callcenter:'';?>">
                       	 			 <input id="agents" name="agents" type="hidden" value="<?php echo isset($agents)?$agents:'';?>">
                       				 <input id="areatype" name="areatype" type="hidden" value="<?php echo isset($areatype)?$areatype:'';?>">
                                	<input type="radio" id="rb1" name="rb" value="" checked>
									<label for="rb1">National</label>
								</div>
                                </div>
                                <div class="col-sm-6">
                                	<div class="radio">
                                	<input type="radio" id="rb2" name="rb" value="">
									<label for="rb2">Specific Location</label>
								</div>
                                </div>
                                
                                <div class="col-sm-6">
                                	<div class="radio">
                                	
                                	<input type="radio" id="rb3" name="rb" value="">
									<label for="rb3">Select Province(s)</label>
								
								</div>
                                </div>
                                
                            </form>
                            
                        </div>
                    </div>
                
                <div class="row">
                	<div class="power_btn">
                    	<div class="back_btn">
                        	<div class="input-group select_num_box blue_btn">
                            	<span class="input-group-addon"><i class="fa fa-arrow-left" aria-hidden="true"></i></span>
                            	<button id="back" type="button" class="btn" style="background: none; width: 100%">Back</button>
                                 
                            </div>
                        </div>
                        
                       <div class="next_btn">
                        	<div class="input-group select_num_box green_btn">
                            	<button id="next" type="button" class="btn" style="background: none; width: 100%">Next</button>
                            	<span class="input-group-addon"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                            </div>
                        </div>
                        	Powerd by<br>
                            <h6>BASTION & FLOWE</h6>
                            digital integration
                        </div>
                </div>
                </div>
            </div>
        </div>
    	
</section>
