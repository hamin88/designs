<!-- comformation_modal JavaScript -->
 <script type="text/javascript">
 $( document ).ready(function() {
  $('#alert').hide();
 });
 function deleteuser(id){
	     $('#alert').hide();
	     $("#activeRecord").html(id);
		 $("#deleteModal").modal();
}
 function deleteconfirm(id){
	 var url = 'deleteUser';
	 var data = {
             id: $('#activeRecord').html()
	 };
	 $.ajax({
		  type: "POST",
		  url: url,
		  cache: false,
		  data: data,
		  success:function(response){
                 var result =$.parseJSON(response);
                 if(result){
               	   window.location= '<?php base_url().'app/users' ?>';
                 }else{
               	   showMessage("User is not deleted.");
               	   $('#alert').show();
                 }
                   
        }
		 });
		
}
</script>
<div id="activeRecord" style="display: none;"></div>
 <!-- comformation_modal JavaScript -->
    
<div class="modal fade" id="deleteModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body" style="padding:40px 18px;">
           Are You sure want to delete this record?<br><br>
          <button type="button" onclick="deleteconfirm();" class="btn comfirm_btn" data-dismiss="modal">Yes</button>
          <button type="button" class="btn comfirm_btn" data-dismiss="modal">No</button>
        </div>
        
      </div>
      
    </div>
  </div>
  
<section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box dashboard">
                	<div class="col-sm-12">
                    
                    	<div class="h_text">
                        	<h4>Admin Section</h4>
                        </div>
                        <div class="h_text">
                            <div class="row">
                            	<div class="col-sm-12">
                                	   <div class="col-sm-3 clearfix">
                                	    <a href = "adduser"  class="btn btn-default edit_btn" style="text-decoration: none;">Create New User </a>
                                    </div>
                                </div>
                                <div id="alert" class="alert alert-success col-sm-10" style="margin-top: 0%; width:100%; text-align: left;">
                                         <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                         <div id="alertMsg"></div>
                               </div>
                                <div class="col-sm-12">
                                	<div class="tap_to_scroll tablete">tap to scroll <strong>&raquo;</strong></div>
                                	<div class="table-responsive">
               	  					  <table class="table table-bordered">
                              <tr bgcolor="#333">
                                <td width="8%" align="left">Username</td>
                                <td width="12%" align="center">First name</td>
                                <td width="6%" align="center">Surname</td>
                                <td width="15%" align="center">Contact number</td>
                                <td width="10%" align="center">Link to client</td>
                                <td width="12%" align="center">User levels</td>
                                <td width="5%" align="center">Edit</td>
                                <td width="7%" align="center">Delete</td>
                              </tr>
                              <?php foreach ($records as $rec){?>
                              <tr>
                                <td align="left"><?php echo $rec['username']; ?></td>
                                <td><?php echo $rec['first_name']; ?></td>
                                <td><?php echo $rec['surname']; ?></td>
                                <td><?php echo $rec['contact']; ?></td>
                                <td><?php echo $rec['client_name']; ?></td>
                                <td><?php echo $rec['userlevelname']; ?></td>
                                <td><div class="edit_btn small_btn"><a href="edituser?id=<?php echo $rec['id']?>" style="text-decoration: none;">Edit</a></div></td>
                                <td><div class="edit_btn small_btn "><a class="deleteBtn" href="javascript:deleteuser(<?php echo $rec['id']?>);" style="text-decoration: none;">Delete</a></div></td>
                              </tr>
                              <?php }?>
                            </table>
                            	</div>

              </div>
                            </div>
                            
                        </div>
              </div>
                	
                
              <div class="row">
                	<div class="power_btn">
                        	Powerd by<br>
                            <h6>BASTION & FLOWE</h6>
                            digital integration
                        </div>
                </div>
                </div>
            </div>
        </div>
    </div>
    	
</section>

