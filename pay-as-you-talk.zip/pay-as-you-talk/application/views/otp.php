<script type="text/javascript">
$( document ).ready(function() {
	$('#alert').hide();
    function checkRequired(id){
    	var value = $('#'+id).val().trim();
    	if(value.length==0){
    	    return false;
        }
        return true;
       
     }

    function showMessage(msg){
    	  $('#alertMsg').html(msg);
     } 

    $('#confirm').click(function() {
    	var data = { 
    	    	'pin' : $('#pin').val(),
    			'generatedotp' : $('#generatedotp').val(),
    			'callcenter' : $('#callcenter').val(),
    			'agents' : $('#agents').val(),
    			'leadstotal': (parseInt($('#agents').val(),0)*250),
    			'areatype' : $('#areatype').val(),
    			'selectedprovince': $('#selectedprovince').val(),
    			'mapradius': $('#mapradius').val(),
    			'maplangitude': $('#maplangitude').val(),
    			'maplatitude': $('#maplatitude').val(),
         };
    	var url = 'createcampaign';
    	$.ajax({
  		  type: "POST",
  		  url: url,
  		  cache: false,
  		  data: data,
  		  success:function(response){
                    var result =$.parseJSON(response);
                    if(result.success){
                  	    window.location="../app/complete";
                    }else{
                  	  showMessage(result.message);
                  	  $('#alert').show();
                    }
                      
           }
  		});

     });
    $('#back').click(function() {
        if($('#areatype').val()=='2'){
        	 $("#form").attr('action', 'location');
         }  else if($('#areatype').val()=='3'){
        	 $("#form").attr('action', 'selectprovinces');
         }else{
        	 $("#form").attr('action', 'selecttarget');
         }
    	$('#form').submit();
     });
});
  </script>
 
<section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box">
                
                <div id="alert" class="alert alert-success col-sm-10"
							style="margin-top: 0%; width: 100%; text-align: left;">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<div id="alertMsg"></div>
				</div>
                	<div class="col-sm-12">
                	<form  method="POST"  role="form" id="form" >   
                    	<div class="h_text">
                        	<h4>Conformation</h4>
                        </div>
                        
                        <div class="h_text conform_text">
                        	A One Time Pin (OTP) was SMS'd to mobile number :<br>
										<strong><?php echo isset($mobile)?$mobile:'';?></strong><br><br>
                        </div>
                        
                        <div class="h_text conform_text">
                        	<h5>Select data destination</h5><br>
                            By confirming the OTP, you agree that you have checked and accepted that the selected imformation is correct and that you accept our terms & conditions.
                        </div>
                        
                        <div class="h_text conform_botom clearfix">
                        	
                            	<h5 class="pull-left">One Time Pin : &nbsp;&nbsp;</h5>
                            <div class="input-group select_num_box">
                                 <input id="callcenter" name="callcenter" type="hidden" value="<?php echo isset($callcenter)?$callcenter:'';?>">
                       	         <input id="agents" name="agents"type="hidden" value="<?php echo isset($agents)?$agents:'';?>">
                       	         <input id="areatype" name="areatype" type="hidden" value="<?php echo isset($areatype)?$areatype:'';?>">
                       	         <input id="mapradius" name="mapradius" type="hidden" value="<?php echo isset($mapradius)?$mapradius:'';?>">
                       	         <input id="maplangitude" name="maplangitude" type="hidden" value="<?php echo isset($maplangitude)?$maplangitude:'';?>">
                       	         <input id="maplatitude" name="maplatitude" type="hidden" value="<?php echo isset($maplatitude)?$maplatitude:'';?>">
                       	         <input id="geocomplete" name="geocomplete" type="hidden" value="<?php echo isset($geocomplete)?$geocomplete:'';?>">
                       	         <input id="leadstotal" name="leadstotal" type="hidden" value="<?php echo isset($leadstotal)?$leadstotal:'';?>">
                       	         <input id="selectedprovince" name="selectedprovince" type="hidden" value="<?php echo isset($selectedprovince)?$selectedprovince:'';?>">
                                 <input type="hidden" class="form-control" id="date" value="<?php echo isset($date)?$date:'';?>">
                                 <input type="hidden" class="form-control" id="otp" value="<?php echo isset($otp)?$otp:'';?>">
                                 <input type="hidden" class="form-control" id="generatedotp" value="<?php echo isset($generatedotp)?$generatedotp:'';?>">
                                 <input type="text" class="form-control" id="pin" placeholder="PIN">
                            </div>
                            <div class="input-group select_num_box confirm_btn">
                            	<button id="confirm" type="button" class="btn" style="background: none; width: 100%">Confirm</button>
                                 <span class="input-group-addon"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                            </div>
                            
                        </div>
                </form>        
                    </div>
                
                
                <div class="row">
                	<div class="power_btn">
                    	<div class="back_btn">
                        	<div class="input-group select_num_box blue_btn">
                            	<span class="input-group-addon"><i class="fa fa-arrow-left" aria-hidden="true"></i></span>
					         	<button id="back" type="button" class="btn" style="background: none; width: 100%">Back</button>                              
                            </div>
                        </div>
                        
                        
                        	Powerd by<br>
                            <h6>BASTION & FLOWE</h6>
                            digital integration
                        </div>
                </div>
                </div>
            </div>
        </div>
    </div>
    	
</section>
