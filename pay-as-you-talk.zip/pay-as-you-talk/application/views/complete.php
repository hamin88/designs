<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">

    <!-- About Section -->
    
<section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box">
                
                	<div class="col-sm-12">
                    	<div class="h_text">
                        	<h4>Complete</h4>
                        </div>
                        
                        <div class="h_text">
                        	<h5>Thank you.</h5>
                        	Your order has been received and will be processed shortly.<br><br>
                            You will be notified via email once the data has been loaded onto your system via the selected API.<br><br>
                            
                            For assistance :087 351 6492 | <a href="mailto:help@bastionflowe.com">help@bastionflowe.com</a><br><br>
                            
                            Click <strong>New</strong> to start a new order.
                        </div>
                        
                    </div>
                
                
                <div class="row">
                	<div class="power_btn">
                    	
                        
                        <div class="next_btn">
                        	<div class="input-group select_num_box green_btn">
                            	<a href="#">Close</a>
                            	<span class="input-group-addon"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                            </div>
                        </div>
                        	Powerd by<br>
                            <h6>BASTION & FLOWE</h6>
                            digital integration
                        </div>
                </div>
                </div>
            </div>
        </div>
    </div>
    	
</section>
