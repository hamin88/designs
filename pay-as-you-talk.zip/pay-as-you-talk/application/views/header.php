<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">

<title>Pay As You Talk</title>

<!-- Bootstrap Core CSS -->
<link href="<?php echo base_url();?>css/bootstrap.min.css"
	rel="stylesheet">

<!-- Custom Fonts -->
<link
	href="<?php echo base_url();?>font-awesome/css/font-awesome.min.css"
	rel="stylesheet" type="text/css">
<link
	href="http://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic"
	rel="stylesheet" type="text/css">
<link href="http://fonts.googleapis.com/css?family=Montserrat:400,700"
	rel="stylesheet" type="text/css">

<!-- Theme CSS -->
<link href="<?php echo base_url();?>css/grayscale.min.css"
	rel="stylesheet">
<link href="<?php echo base_url();?>css/main_page.css" rel="stylesheet">
<!-- Morris Charts CSS -->            <?php if($this->session->userdata('logged_in') == TRUE) { ?>    <link
	href="<?php echo base_url();?>css/plugins/morris.css" rel="stylesheet"><?php } ?>    <!-- jQuery -->
<script src="<?php echo base_url();?>js/jquery.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
<!-- Plugin JavaScript -->
<script
	src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<!-- Theme JavaScript -->
<script src="<?php echo base_url();?>js/timeslide.js"></script>
<script src="<?php echo base_url();?>js/grayscale.min.js"></script>
<!-- Plugin JavaScript -->
<script
	src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top"><?php if($this->session->userdata('logged_in') == TRUE) { ?><div
		class="menu_part">
		<nav class="navbar navbar-default bg_color">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse"
					data-target="#myNavbar">
					<span class="icon-bar"></span> <span class="icon-bar"></span> <span
						class="icon-bar"></span>
				</button>
				<a class="navbar-brand small_logo" href="#"><img
					src="<?php echo base_url();?>images/logo_small.png"
					class="img-responsive" alt=""></a>
			</div>
			<div class="collapse navbar-collapse" id="myNavbar">
				<ul class="nav navbar-nav navbar-right">                          
				<?php if($this->session->userdata('user_level') != 1) { ?>                           
				  <li><a href="<?php echo base_url();?>app/newcampaign">New</a></li>
					<li><a href="<?php echo base_url();?>app/history">History</a></li>
					<li><a href="<?php echo base_url();?>app/result1">Results</a></li>
					<li><a href="<?php echo base_url();?>app/helps">Helps</a></li>                            
					<?php } else {?>   
					<li><a href="<?php echo base_url();?>app/callcenters">Call Centers</a></li>                                                       
					<li><a href="<?php echo base_url();?>app/clients">Clients</a></li>
					<li><a href="<?php echo base_url();?>app/users">Users</a></li>
					<?php }?>                                                             
					<li><a href="<?php echo base_url();?>app/logout">Logout</a></li>
				</ul>
			</div>
		</nav>
	</div><?php } else {?><nav class="navbar navbar-default bg_color"></nav><?php }?>          
