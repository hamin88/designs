<style>
.fileUpload {
    position: relative;
    overflow: hidden;
    margin: 10px;
}
.fileUpload input.upload {
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    padding: 0;
    font-size: 20px;
    cursor: pointer;
    opacity: 0;
    filter: alpha(opacity=0);
}
</style>

<!-- comformation_modal JavaScript -->
 <script type="text/javascript">
 $( document ).ready(function() {
  $('#alert').hide();

 $('#uploadBtn').change(function(){
	    $('#apifile').val($('#uploadBtn').val());
 });
  
 $('#next').click(function() {
	  $('#form').submit();
 });
 
});		
</script>
<section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box">
                
                	<div class="col-sm-12">
                    	<div class="h_text">
                        	<h4>Upload</h4>
                            Upload you results in a CSV format
                        </div>
                        
                        <div class="h_text">

                            	<form role="form" method="POST" action="result2" role="form" id="form" enctype="multipart/form-data">
                                	<h5 class="pull-left">Select file : &nbsp;&nbsp;</h5>
                                    <div class="input-group upload_box">
                                        <input id="apifile" name="apifile" placeholder="Choose File" disabled="disabled"> 
                                         
                                           <div class="fileUpload btn btn-primary">
                                                <span>Upload</span>
                                                <input id="uploadBtn" type="file" name="file" class="upload" />
                                            </div>  
                                         
                                    </div>
                                    
                        		</form>
                        </div>
                        
                        
                    </div>
                
                
                <div class="row">
                	<div class="power_btn">
                    	
                        
                        <div class="next_btn">
                        	<div class="input-group select_num_box green_btn">
                            	<button id="next" type="button" class="btn" style="background: none; width: 100%">Next</button>
                            	<span class="input-group-addon"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                            </div>
                        </div>
                        	Powerd by<br>
                            <h6>BASTION & FLOWE</h6>
                            digital integration
                        </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</section>