<style>
.fileUpload {
    position: relative;
    overflow: hidden;
    margin: 10px;
}
.fileUpload input.upload {
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    padding: 0;
    font-size: 20px;
    cursor: pointer;
    opacity: 0;
    filter: alpha(opacity=0);
}
</style>

<script type="text/javascript">
$( document ).ready(function() {
    $('#alert').hide();

    function checkRequired(id){
    	var value = $('#'+id).val().trim();
    	if(value.length==0){
    	    return false;
        }
        return true;
       
     }
    function checkSelected(id){
    	var value = $('#'+id).val();
    	if(value==null || value.length==0){
    	    return false;
        }
        return true;
       
     }
    function showMessage(msg){
    	  $('#alertMsg').html(msg);
     }

    $('#uploadBtn').change(function(){
	    $('#apifile').val($('#uploadBtn').val());
	   
    });
    
    $('#save').click(function() {
  	  $('#alert').hide();
  	  if(!checkRequired('clientname')){
      	  showMessage("Client name is required field.");
      	  $('#alert').show();  
        }else if(!checkSelected('callcenter')){
      	  showMessage("Callcenter name is required field.");
    	  $('#alert').show();  
        }else if(!checkRequired('address')){
      	  showMessage("Address is required field.");
      	  $('#alert').show();  
      
         }else if(!checkRequired('billing')){
         	  showMessage("Billing rate is required field.");
          	  $('#alert').show();  
          
         }else{           
        	  $('#form').submit();
           }
    });
});
</script>
<section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box dashboard">
                	<div class="col-sm-12">
                    
                    	<div class="h_text">
                        	<h4>Add client Details</h4>
                        </div>
                          
                        <div class="h_text">
                                     
                            <div class="row">
                             
                             <div id="alert" class="alert alert-success col-sm-10" style="margin-top: 0%; width:100%; text-align: left;">
                                         <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                         <div id="alertMsg"></div>
                               </div>
                               
                            	<div class="col-sm-12">
                            	
                            	
                            	
                                	<div class="col-sm-10">
  
                                    	<div class="admin_table">
                                    	<form class="form-horizontal" method="POST" action="insertclient" role="form" id="form" enctype="multipart/form-data">
                                    		
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="clientname">Client Name</label>
                                          <div class="col-sm-8 border_left">
                                            <input type="text" class="form-control" id="clientname" name="clientname" placeholder="clientname">
                                          </div>
                                        </div>
                                        
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="callcenter">Callcenter Name</label>
                                          <div class="col-sm-8 border_left">          
                                            <select id="callcenter" name="callcenter[]" class="form-control" multiple="multiple">
                                            <?php foreach ($callcenters as $callcenter ) {
                                            
                                            	 if(isset($_GET['ccid']) && $_GET['ccid']==  $callcenter['id']){
                                            	   ?>
                                            	 	<option value="<?php echo  $callcenter['id'] ;?>" selected="selected"><?php echo  $callcenter['name'] ;?></option>
                                            	 <?php	                                               
                                            	 }else{
                                            	 	?>
                                            	 	<option value="<?php echo  $callcenter['id'] ;?>"><?php echo  $callcenter['name'] ;?></option>
                                            	 <?php	
                                            	 }
                                            	 }?>
                                            </select>   
                                          </div>
                                        </div>
                                        
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="address">address</label>
                                          <div class="col-sm-8 border_left">          
                                            <textarea class="form-control" id="address" name="address" placeholder="address" rows="3"></textarea>
                                          </div>
                                        </div>
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="billing">Billing Rate(per second)</label>
                                          <div class="col-sm-8 border_left">          
                                           <input type="number" step="0.001"  id="billing"  name="billing" placeholder="Billing Rate" 
                                             onchange="changeNumeric('billing');" >
                                          </div>
                                        </div>
                                        
                                        <div class="form-group" style="margin-top:10px">
                                          <div class="col-sm-4 col-sm-offset-8 "> 
                                           <div class="col-sm-6"> 
                                           <button id="save" type="button" class="btn btn-default edit_btn">Save </button>
                                          </div>
                                          <div class="col-sm-6">     
                                             <a href = "users"  class="btn btn-default edit_btn" style="text-decoration: none;">Cancel</a>
                                          </div>         
                                          </div>
                                        </div>
                                      </form>
                                      	</div>
                                  </div>
                                </div>
                                
                             </div>
                            
                        </div>
              </div>
                	
                
              <div class="row">
                	<div class="power_btn">
                        	Powerd by<br>
                            <h6>BASTION & FLOWE</h6>
                            digital integration
                        </div>
                </div>
                </div>
            </div>
        </div>
    </div>
    	
</section>

