<script type="text/javascript">
$( document ).ready(function() {
	 $('#selectedprovince').val("<?php echo isset($selectedprovince)?$selectedprovince:'All'; ?>");
	 if($('#selectedprovince').val()!=''){
		 var radios = $('input:radio[name=rb]');
         for(var i=0;i<radios.length;i++){
        	 if(radios[i].value == $('#selectedprovince').val()){
        		 radios[i].checked=true;
             }
		}
	}else{
		var radios = $('input:radio[name=rb]');
		 radios[0].checked=true;
	}
    
    $('#next').click(function() {
    	var radios = $('input:radio[name=rb]');
         for(var i=0;i<radios.length;i++){
        	 if(radios[i].checked){
        		 $("#selectedprovince").val(radios[i].value);
             }
         }
        $("#form").attr('action', 'otp');
    	$('#form').submit();
    });
    $('#back').click(function() {
    	$("#form").attr('action', 'selecttarget');
    	$('#form').submit();
     });
});
</script>
<section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box">
                
                	<div class="col-sm-12">
                    	<div class="h_text">
                        	<h4>Targeted Area Selection > Provinces</h4>
                            Select the Province(s) you'd like to market to.
                        </div>
                        
                        <div class="h_text clearfix">
                        	<h5>Targeted Province(s)</h5>
			<form  class="form-horizontal" method="POST" action="otp" role="form" id="form" >          
                 				 	<div class="col-sm-12">
                                	<div class="radio">
                                	<input id="callcenter" name="callcenter" type="hidden" value="<?php echo isset($callcenter)?$callcenter:'';?>">
                       	         <input id="agents" name="agents"type="hidden" value="<?php echo isset($agents)?$agents:'';?>">
                       	         <input id="areatype" name="areatype" type="hidden" value="<?php echo isset($areatype)?$areatype:'';?>">
                                	<input type="hidden" id="selectedprovince"  name="selectedprovince"
                                	value="<?php echo isset($selectedprovince)?$selectedprovince:'';?>">
                                	<input type="radio" id="rb1" name="rb" value="All">
									<label for="rb1">All</label>
								</div>
                                </div>
                                
                                
                                <div class="col-sm-4">
                                	<div class="radio">
                                	<input type="radio" id="rb2" name="rb" value="Gauteng">
									<label for="rb2">Gauteng</label>
								</div>
                                </div>
                                
                                <div class="col-sm-4">
                                	<div class="radio">
                                	<input type="radio" id="rb3" name="rb" value="Western Cape">
									<label for="rb3">Western Cape</label>
								</div>
                                </div>
                                
                                <div class="col-sm-4">
                                	<div class="radio">
                                	<input type="radio" id="rb4" name="rb" value="Northern Cape">
									<label for="rb4">Northern Cape</label>
								</div>
                                
                                </div>
                                
                                
                                <div class="col-sm-4">
                                	<div class="radio">
                                	<input type="radio" id="rb5" name="rb" value="Limpopo">
									<label for="rb5">Limpopo</label>
								</div>
                                </div>
                                
                                <div class="col-sm-4">
                                	<div class="radio">
                                	<input type="radio" id="rb6" name="rb" value="Eastern Cape">
									<label for="rb6">Eastern Cape</label>
								</div>
                                </div>
                                
                                <div class="col-sm-4">
                                	<div class="radio">
                                	<input type="radio" id="rb7" name="rb" value="North West">
									<label for="rb7">North West</label>
								</div>
                                
                                </div>
                                
                                <div class="col-sm-4">
                                	<div class="radio">
                                	<input type="radio" id="rb8" name="rb" value="Free State">
									<label for="rb8">Free State</label>
								</div>
                                </div>
                                
                                <div class="col-sm-4">
                                	<div class="radio">
                                	<input type="radio" id="rb9" name="rb" value="Mpumalanga">
									<label for="rb9">Mpumalanga</label>
								</div>
                                </div>
                                
                                <div class="col-sm-4">
                                	<div class="radio">
                                	<input type="radio" id="rb10" name="rb" value="Kawazulu Natal">
									<label for="rb10">Kawazulu Natal</label>
								</div>
                                
                                
                                
                                </div>
                                
                            </form>
                            
                        </div>
                    </div>
                
                <div class="row">
                	<div class="power_btn">
                    	<div class="back_btn">
                        	<div class="input-group select_num_box blue_btn">
                            	<span class="input-group-addon"><i class="fa fa-arrow-left" aria-hidden="true"></i></span>
                            	<button id="back" type="button" class="btn" style="background: none; width: 100%">Back</button>
                                 
                            </div>
                        </div>
                        
                          <div class="next_btn">
                        	<div class="input-group select_num_box green_btn">
                            	<button id="next" type="button" class="btn" style="background: none; width: 100%">Next</button>
                            	<span class="input-group-addon"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                            </div>
                        </div>
                        	Powerd by<br>
                            <h6>BASTION & FLOWE</h6>
                            digital integration
                        </div>
                </div>
                </div>
            </div>
        </div>
    	
</section>