
<!-- <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyBxXmC--vDhhffL8g5uxOLPgRPnNnCJaZA"></script>  -->

<script src="http://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places"></script>
<script src="http://ubilabs.github.io/geocomplete/jquery.geocomplete.js"></script> 
<script src="http://ubilabs.github.io/geocomplete/jquery.geocomplete.js"></script>    
  
<script>
/*
function initialize()
{
  var mapProp = {
      
    center: new google.maps.LatLng(51.508742,-0.120850),
    zoom:9,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  };
   
  var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
}

google.maps.event.addDomListener(window, 'load', initialize);

*/

$(document).ready(function(){
  var options = {
    map: ".map_canvas"
  };
  
  $("#geocomplete").geocomplete(options)
    .bind("geocode:result", function(event, result){
      $.log("Result: " + result.formatted_address);
    })
    .bind("geocode:error", function(event, status){
      $.log("ERROR: " + status);
    })
    .bind("geocode:multiple", function(event, results){
      $.log("Multiple: " + results.length + " results found");
    });
  
  $("#find").click(function(){
    $("#geocomplete").trigger("geocode");
  });
  
  $("#examples a").click(function(){
    $("#geocomplete").val($(this).text()).trigger("geocode");
    return false;
  });
  
});
</script>

    
    




<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
   
<section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box">
                
                	<div class="col-sm-12">
                    	<div class="h_text">
                        	<h4>Targeted Area Selection > Specific Location</h4>
                            Drop the locator pin on the specific area you wish to target or type the physical address in the  address bar.
                        </div>
                        
                        <div class="h_text">
                        	
                            	<h5 class="pull-left">Physical Address : &nbsp;&nbsp;</h5>
                          <form  class="form-horizontal" method="POST" action="numberofagents" role="form" id="form" >
                            <div class="input-group select_box">
                            <input id="geocomplete" type="text" placeholder="Type in an address" size="90" />
                                <select class="form-control">
                                	<option>Central South Affrica</option>
                                    <option>2</option>
                                    <option>3</option>
                                    <option>4</option>
                                    <option>5</option>
								</select>
                            </div>
                            
                        </form>
                        </div>
                        <div class="row map_part">
                        	<div class="col-sm-8"><div id="googleMap" ></div></div>
                            <div class="col-sm-4">
                            	<div class="h_text margin_top clearfix">
                            		<h5 class="pull-left">Radius : &nbsp;&nbsp;</h5>
                            		<form role="form">
                                        <div class="input-group select_num_box">
                                            <select class="form-control">
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                            </select>
                                        </div>
                            
                        </form>
                        		</div>
                            </div>
                        </div>
                        
                    </div>
                
                
                <div class="row">
                	<div class="power_btn">
                    	<div class="back_btn">
                        	<div class="input-group select_num_box blue_btn">
                            	<span class="input-group-addon"><i class="fa fa-arrow-left" aria-hidden="true"></i></span>
                            	<a href="selecttarget">Back</a>
                                 
                            </div>
                        </div>
                        
                          <div class="next_btn">
                        	<div class="input-group select_num_box green_btn">
                            	<button id="next" type="button" class="btn" style="background: none; width: 100%">Next</button>
                            	<span class="input-group-addon"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                            </div>
                        </div>
                        	Powerd by<br>
                            <h6>BASTION & FLOWE</h6>
                            digital integration
                        </div>
                </div>
                </div>
            </div>
        </div>
    </div>
    	
</section>

   