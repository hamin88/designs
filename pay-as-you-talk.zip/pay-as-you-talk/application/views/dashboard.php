 <!-- Morris Charts JavaScript -->
 <script src="<?php echo base_url();?>js/plugins/morris/raphael.min.js"></script>
 <script src="<?php echo base_url();?>js/plugins/morris/morris.min.js"></script>
 <script src="<?php echo base_url();?>js/plugins/morris/morris-data2.js"></script>
 

<section class="login-section">

	<div class="container">

    	<div class="row">

        	<div class="login_box dashboard">
                   <div class="col-sm-12">
                    
                    	<div class="h_text">
                        	<h4><font color="#FFFFFF">Welcome : </font><?php echo isset($name)?$name:''; ?></h4>
                        </div>
                        
                        <div class="h_text">
                        	<div class="col-sm-6">
                            	<div class="dash_list">
                                	<ul class="clearfix">
                                    	<li>Active Campaigns :</li>
                                        <li class="large_text"><?php echo isset($activecampaigns)?$activecampaigns:'0'; ?></li>
                                    </ul>
                                    
                                    <ul class="clearfix">
                                    	<li>Results required :</li>
                                        <li class="large_text">00</li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="col-sm-6">
                            	<div class="dash_list">
                                	<ul class="clearfix right_side">
                                    	<li>Leads use this month</li>
                                        <li class="large_text"><?php echo isset($monthcampaigns)?$monthcampaigns:'0'; ?></li>
                                    </ul>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-9">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-bar-chart-o fa-fw"></i> Usage History</h3>
                            </div>
                            <div class="panel-body">
                                <div id="morris-area-chart"></div>
                            </div>
                        </div>
                    </div>
                    		<?php if( isset($callcenters) && !empty($callcenters)) {
                    		
                    			foreach ($callcenters as $callcenter){
                    				
                    	 ?>
                            <div class="col-sm-3 text-left">
                            	<div class="box" style="margin-top:5px"></div> <?php echo $callcenter['name']; ?>
                            </div>
                             <?php 	
                    			}
                    		}
                    		?>
                        </div>
                        
                    </div>
                
                
                <div class="row">
                	<div class="power_btn">
                        	Powerd by<br>
                            <h6>BASTION & FLOWE</h6>
                            digital integration
                        </div>
                </div>
                 </div>

            </div>

        </div>
</section>
               
    <script>

   $(document).ready(function(){ 

	   var data = new Array();
	    <?php foreach($usage as $key => $val){ ?>
	    data.push({
	        	period: '<?php echo $key; ?>',
	        	usage: '<?php echo !empty($val)?$val:0 ; ?>'
		        });
	  <?php } ?>
	    
  var months = ["Jan", "Feb", "Mar", "April", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec"];

  // Area Chart

  Morris.Area({
      element: 'morris-area-chart',
      data:data,
      xkey: 'period',

      ykeys: ['usage'],

      labels: ['Usage'],

      pointSize: 2,

      hideHover: 'auto',

      resize: true,

		xLabels : "month",

		xLabelFormat : function(x) { 

           var month = months[x.getMonth()];

            return month;

      }


  }); 



  });
  </script>