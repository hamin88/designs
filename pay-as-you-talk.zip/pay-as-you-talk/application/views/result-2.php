<script type="text/javascript">
$( document ).ready(function() {
	 $('#next').click(function() {
		  $('#form').submit();
	 });
	 
 });
</script>
<section class="login-section">
	<div class="container">
		<div class="row">
			<div class="login_box">
				<div class="col-sm-12">
					<div class="h_text">
						<h4>Upload > Match Fields</h4>
						Upload you results in a CSV format
					</div>
					<div class="h_text upload">
						<form id= "form" method="POST"  role="form" action="result3">
							<h5 class="pull-left">Call date & time : &nbsp;&nbsp;</h5>
							<div class="input-group upload_box">
							<input id="destinationpath" name="destinationpath" type="hidden" value="<?php echo isset($destinationpath)?$destinationpath:''; ?>">
								<select id="calldates" name="calldates" class="form-control">
									<option value="">Select</option>											
								 <?php if(!empty($fields)) {													
										foreach ($fields as $field) {													
											echo  '<option>'.$field.'</option>';												
										}											
									} ?>                                       
									 </select>
							</div>
							<h5 class="pull-left">Number phoned : &nbsp;&nbsp;</h5>
							<div class="input-group upload_box">
								<select id="phone_number" name="phone_number" class="form-control">
									<option value="">Select</option>											
								 <?php if(!empty($fields)) {													
										foreach ($fields as $field) {													
											echo  '<option>'.$field.'</option>';												
										}											
									} ?>                                       
									 </select>
							</div>
							<h5 class="pull-left">Lead Identifier : &nbsp;&nbsp;</h5>
							<div class="input-group upload_box">
								<select id="lead_id" name="lead_id" class="form-control">
									<option value="">Select</option>											
								 <?php if(!empty($fields)) {													
										foreach ($fields as $field) {													
											echo  '<option>'.$field.'</option>';												
										}											
									} ?>                                       
									 </select>
							</div>
							<h5 class="pull-left">Call length : &nbsp;&nbsp;</h5>
							<div class="input-group upload_box">
								<select id="length_in_sec" name="length_in_sec" class="form-control">
									<option value="">Select</option>											
								 <?php if(!empty($fields)) {													
										foreach ($fields as $field) {													
											echo  '<option>'.$field.'</option>';												
										}											
									} ?>                                       
									 </select>
							</div>
							<h5 class="pull-left">Outcome : &nbsp;&nbsp;</h5>
							<div class="input-group upload_box">
								<select id="outcome" name="outcome" class="form-control">
									<option value="">Select</option>											
								 <?php if(!empty($fields)) {													
										foreach ($fields as $field) {													
											echo  '<option>'.$field.'</option>';												
										}											
									} ?>                                       
									 </select>
							</div>
							<h5 class="pull-left">Campaign Identifier : &nbsp;&nbsp;</h5>
							<div class="input-group upload_box">
								<select id="campaign_id" name="campaign_id" class="form-control">
									<option value="">Select</option>											
								 <?php if(!empty($fields)) {													
										foreach ($fields as $field) {													
											echo  '<option>'.$field.'</option>';												
										}											
									} ?>                                       
									 </select>
							</div>
						</form>
					</div>
				</div>
				<div class="row">
					<div class="power_btn">
						<div class="next_btn">
							<div class="input-group select_num_box green_btn">
								<button id="next" type="button" class="btn" style="background: none; width: 100%">Next</button>
								<span class="input-group-addon"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
							</div>
						</div>
						Powerd by<br>
						<h6>BASTION & FLOWE</h6>
						digital integration
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
