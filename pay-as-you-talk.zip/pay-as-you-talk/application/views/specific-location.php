   <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/mapstyle.css" />
  
    <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDpNuN0DBtKhZ_qqaeVUH96zU7MDC7qA04&sensor=false&amp;libraries=places"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    <!-- 
     <link rel="stylesheet" type="text/css" href="http://ubilabs.github.io/geocomplete/examples/styles.css" />
    <script src="http://ubilabs.github.io/geocomplete/jquery.geocomplete.js"></script> 
     <script src="http://ubilabs.github.io/geocomplete/examples/logger.js"></script>
    
    -->
    <script src="<?php echo base_url();?>js/jquery.geocomplete.js"></script>
    <script src="<?php echo base_url();?>js/logger.js"></script>
     
    <script>

    $(document).ready(function(){

    	$('#alert').hide();
        function checkRequired(id){
        	var value = $('#'+id).val().trim();
        	if(value.length==0){
        	    return false;
            }
            return true;
           
         }
        function showMessage(msg){
      	  $('#alertMsg').html(msg);
       }
        
    	$('#mapradius').val("<?php echo isset($mapradius)?$mapradius:'5'; ?>");
    	$('#geocomplete').val("<?php echo isset($geocomplete)?$geocomplete:'5'; ?>");
        var options = {
          map: ".map_canvas"
        };
        
        $("#geocomplete").geocomplete(options)
          .bind("geocode:result", function(event, result){
        	  $('#maplangitude').val(result.geometry.location.lat());
        	  $('#maplatitude').val(result.geometry.location.lng());
       	      
            $.log("Result: " + result.formatted_address);
          })
          .bind("geocode:error", function(event, status){
            $.log("ERROR: " + status);
          })
          .bind("geocode:multiple", function(event, results){
            $.log("Multiple: " + results.length + " results found");
          });
        
        $("#find").click(function(){
          $("#geocomplete").trigger("geocode");
        });
        $('#close-alert').click(function() {
        	$('#alert').hide();
        });
        $('#next').click(function() {
        	if(!checkRequired('geocomplete')){
            	  showMessage("Please select the location.");
            	  $('#alert').show();  
            	  return false;
           
            }
            
        	$("#form").attr('action', 'otp');
        	$('#form').submit();
         });

        $('#back').click(function() {
        	$("#form").attr('action', 'selecttarget');
        	$('#form').submit();
         });

        if($('#geocomplete').val()!=''){
   		  $("#geocomplete").trigger("geocode");
       }
        
      });
 </script>


<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
   
<section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box">
        	 <div id="alert" class="alert alert-success col-sm-10"
							style="margin-top: 0%; width: 100%; text-align: left;">
							<a id="close-alert" href="javascript:void(0);"  class="close"  aria-label="close">&times;</a>
							<div id="alertMsg"></div>
				</div>
                  <form  class="form-horizontal" method="POST" action="otp" role="form" id="form" >
                	<div class="col-sm-12">
                    	<div class="h_text">
                        	<h4>Targeted Area Selection > Specific Location</h4>
                            Drop the locator pin on the specific area you wish to target or type the physical address in the  address bar.
                        </div>
                        
                        <div class="h_text">
                            	<h5 class="pull-left">Physical Address : &nbsp;&nbsp;</h5>
                            <div class="input-group select_box">
                             <input id="callcenter" name="callcenter" type="hidden" value="<?php echo isset($callcenter)?$callcenter:'';?>">
                       	     <input id="agents" name="agents"type="hidden" value="<?php echo isset($agents)?$agents:'';?>">
                       	     <input id="areatype" name="areatype" type="hidden" value="<?php echo isset($areatype)?$areatype:'';?>">
                       	      <input id="maplangitude" name="maplangitude" type="hidden">
                       	      <input id="maplatitude" name="maplatitude" type="hidden">
                            <input id="geocomplete"  name="geocomplete"  type="text" class="form-control" placeholder="Type in an address" size="90" />
                            </div>
                        </div>
                        
    
                        <div class="row map_part">
                        	<div class="col-sm-8">
                        	 <div id="googleMap" class="map_canvas"></div>
                        	</div>
                            <div class="col-sm-4">
                            	<div class="h_text margin_top clearfix">
                            		<h5 class="pull-left">Radius : &nbsp;&nbsp;</h5>
                                        <div class="input-group select_num_box">
                                            <select id="mapradius" name="mapradius" class="form-control">
                                                <option>1</option>
                                                <option>2</option>
                                                <option>5</option>
                                                <option>10</option>
                                                <option>20</option>
                                                <option>25</option>
                                                <option>30</option>
                                                <option>40</option>
                                                <option>50</option>                                            
                                            </select>
                                        </div>
                            
                        		</div>
                            </div>
                        </div>
                        
                    </div>
                
                
                <div class="row">
                	<div class="power_btn">
                    	<div class="back_btn">
                        	<div class="input-group select_num_box blue_btn">
                            	<span class="input-group-addon"><i class="fa fa-arrow-left" aria-hidden="true"></i></span>
                            	<button id="back" type="button" class="btn" style="background: none; width: 100%">Back</button>
                                 
                            </div>
                        </div>
                          <div class="next_btn">
                        	<div class="input-group select_num_box green_btn">
                            	<button id="next" type="button" class="btn" style="background: none; width: 100%">Next</button>
                            	<span class="input-group-addon"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                            </div>
                        </div>
                        	Powerd by<br>
                            <h6>BASTION & FLOWE</h6>
                            digital integration
                        </div>
                </div>
                </form>
                </div>
            </div>
        </div>
    	
</section>

   