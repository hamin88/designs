 

<!DOCTYPE html>
<html>
  <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <title>GeoComplete</title>
    
    <link rel="stylesheet" type="text/css" href="http://ubilabs.github.io/geocomplete/examples/styles.css" />
  </head>
  <body>

    <form>
      <input id="geocomplete" type="text" placeholder="Type in an address" size="90" />
      <input id="find" type="button" value="find" />
    </form>
        
    <div id="examples">
      Examples:
      <a href="#">Hamburg, Germany</a>
      <a href="#">Juliusstra�e 25, Germany</a>
      <a href="#">3rr0r</a>
      <a href="#">Hauptstra�e</a>
    </div>
    
    <div class="map_canvas"></div>
    
    <pre id="logger">Log:</pre>
    
    <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDpNuN0DBtKhZ_qqaeVUH96zU7MDC7qA04&sensor=false&amp;libraries=places"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>

    <script src="http://ubilabs.github.io/geocomplete/jquery.geocomplete.js"></script>
    <script src="http://ubilabs.github.io/geocomplete/examples/logger.js"></script>
     
    <script>
      $(function(){
        
        var options = {
          map: ".map_canvas"
        };
        
        $("#geocomplete").geocomplete(options)
          .bind("geocode:result", function(event, result){
            $.log("Result: " + result.formatted_address);
          })
          .bind("geocode:error", function(event, status){
            $.log("ERROR: " + status);
          })
          .bind("geocode:multiple", function(event, results){
            $.log("Multiple: " + results.length + " results found");
          });
        
        $("#find").click(function(){
          $("#geocomplete").trigger("geocode");
        });
        
        $("#examples a").click(function(){
          $("#geocomplete").val($(this).text()).trigger("geocode");
          return false;
        });
        
      });
    </script>
  </body>
</html>

