<section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box dashboard">
                	<div class="col-sm-12">
                    
                    	<div class="h_text">
                        	<h4>401 : Access Denied</h4>
                        </div>
                            
              </div>
                	
              <div class="row">
                	<div class="power_btn">
                        	Powerd by<br>
                            <h6>BASTION &amp; FLOWE</h6>
                            digital integration
                        </div>
                </div>
                </div>
            </div>
        </div>

    	
</section>

