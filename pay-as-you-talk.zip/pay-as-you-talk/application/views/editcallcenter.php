<style>
.fileUpload {
    position: relative;
    overflow: hidden;
    margin: 10px;
}
.fileUpload input.upload {
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    padding: 0;
    font-size: 20px;
    cursor: pointer;
    opacity: 0;
    filter: alpha(opacity=0);
}
</style>

<script type="text/javascript">
$( document ).ready(function() {
    $('#alert').hide();

    function checkRequired(id){
    	var value = $('#'+id).val().trim();
    	if(value.length==0){
    	    return false;
        }
        return true;
       
     }
    function showMessage(msg){
    	  $('#alertMsg').html(msg);
     }

    function showMessage(msg){
  	  $('#alertMsg').html(msg);
   }

  $('#uploadBtn').change(function(){
	    $('#apifile').val($('#uploadBtn').val());
	   
  });
    
    $('#save').click(function() {
  	  $('#alert').hide();
  	  if(!checkRequired('name')){
      	  showMessage("Callcenter name is required field.");
      	  $('#alert').show();  
        }else if(!checkRequired('description')){
      	  showMessage("Description is required field.");
      	  $('#alert').show();  
        }else if(!checkRequired('url')){
      	  showMessage("URL is required field.");
      	  $('#alert').show(); 
        }else if(!checkRequired('apifile')){
       	 showMessage("API File is required field.");
       	 $('#alert').show(); 
        }else if(!checkRequired('filedescription')){
          	 showMessage("API File description is required field.");
           	 $('#alert').show(); 
        }else{                     
           	  $('#form').submit();
         }
    });
});
</script>
<section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box dashboard">
                	<div class="col-sm-12">
                    
                    	<div class="h_text">
                        	<h4>Edit Callcenter Details</h4>
                        </div>
                          
                        <div class="h_text">
                                     
                            <div class="row">
                             
                             <div id="alert" class="alert alert-success col-sm-10" style="margin-top: 0%; width:100%; text-align: left;">
                                         <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                         <div id="alertMsg"></div>
                               </div>
                               
                            	<div class="col-sm-12">
                            	
                            	
                            	
                                	<div class="col-sm-10">
  
                                    	<div class="admin_table">
                                    	<form class="form-horizontal" method="POST" action="updateCallcenter" role="form" id="form" enctype="multipart/form-data">
                                    		
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="name">name</label>
                                          <div class="col-sm-8 border_left">
                                            <input type="hidden" class="form-control" name="id" id="id" value="<?php echo isset($record['id'])?$record['id']:'0'; ?>">
                                            <input type="text" class="form-control" name="name" id="name" placeholder="name" value="<?php echo isset($record['name'])?$record['name']:''; ?>">
                                          </div>
                                        </div>
                                        
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="description">Description</label>
                                          <div class="col-sm-8 border_left">          
                                            <input type="text" class="form-control" name="description" id="description" placeholder="description"
                                            value="<?php echo isset($record['description'])?$record['description']:'' ; ?>" >
                                          </div>
                                        </div>
                                        
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="url">URL</label>
                                          <div class="col-sm-8 border_left">          
                                            <input type="text" class="form-control" name="url" id="url" placeholder="url"
                                            value="<?php echo isset($record['url'])?$record['url']:''; ?>">
                                          </div>
                                        </div>
                                        
                                         <div class="form-group">
                                          <label class="control-label col-sm-4" for="apifile">API File</label>
                                          <div class="col-sm-8 border_left">          
                                            <input id="apifile" name="apifile" placeholder="Choose File" disabled="disabled"
                                             value="<?php echo isset($record['api_file'])?$record['api_file']:''; ?>"  >
                                            <div class="fileUpload btn btn-primary">
                                                <span>Upload</span>
                                                <input id="uploadBtn" type="file" name="file" class="upload" />
                                            </div> 
                                          </div>
                                        </div>
                                        <div class="form-group">
                                          <label class="control-label col-sm-4" for="description">API File Description</label>
                                          <div class="col-sm-8 border_left">          
                                            <input type="text" class="form-control"  id="filedescription"  name="filedescription" placeholder="API File Description" 
                                             value="<?php echo isset($record['api_file_desc'])?$record['api_file_desc']:''; ?>" >
                                          </div>
                                        </div>
                                        
                                         <div class="form-group" style="margin-top:10px">
                                          <div class="col-sm-4 col-sm-offset-8"> 
                                           <div class="col-sm-6"> 
                                           <button id="save" type="button" class="btn btn-default edit_btn">Save </button>
                                          </div>
                                          <div class="col-sm-6">
                                           <a href = "callcenters"  class="btn btn-default edit_btn" style="text-decoration: none;">Cancel</a>
                                          </div>         
                                          
                                          </div>
                                        </div>
                                      </form>
                                      	</div>
                                  </div>
                                </div>
                                
                             </div>
                            
                        </div>
              </div>
                	
                
              <div class="row">
                	<div class="power_btn">
                        	Powerd by<br>
                            <h6>BASTION &amp; FLOWE</h6>
                            digital integration
                        </div>
                </div>
                </div>
            </div>
        </div>
    	
</section>

