<script type="text/javascript">
$( document ).ready(function() {
    $('#alert').hide();

    function checkRequired(id){
    	var value = $('#'+id).val().trim();
    	if(value.length==0){
    	    return false;
        }
        return true;
       
     }
    function checkSelected(id){
    	var value = $('#'+id).val();
    	if(value==null || value.length==0){
    	    return false;
        }
        return true;
       
     }
    function showMessage(msg){
    	  $('#alertMsg').html(msg);
     }

    $('#uploadBtn').change(function(){
	    $('#apifile').val($('#uploadBtn').val());
	   
    });
    
    $('#next').click(function() {
       
  	  $('#alert').hide();
  	  if(!checkRequired('callcenter')){
      	  showMessage("Callcenter is required field.");
      	  $('#alert').show();  
      	  return false;
     
         }else{
        	 $('#form').submit();
            }  
    });
});

</script>

  <section class="login-section">
	<div class="container">
    	<div class="row">
        	<div class="login_box">
        	<form  class="form-horizontal" method="POST" action="numberofagents" role="form" id="form" >
                	<div class="col-sm-12">
                    	<div class="h_text">
                        	<h4>Campaign Details > Call center configuration</h4>
                            you are setting up a new campaign. Enter the basic imformation for this campaign.
                        </div>
                        
                        <div class="h_text">
                        	<h5>Select data destination</h5>
                            This is the destination the Pay- as- You- Talk data will be sent to.
                            <div class="input-group select_box">
                             
                                	 <select id="callcenter" name="callcenter" class="form-control" >
                                            <?php foreach ($callcenters as $tempcallcenter ) {
                                              
                                            	if(isset($callcenter) &&   $callcenter==$tempcallcenter['id'] ){
                                            		
                                               ?>
                                               <option value="<?php echo  $tempcallcenter['id'] ;?>" selected="selected"><?php echo  $tempcallcenter['name'] ;?></option> 
                                                <?php
                                            	}else {
                                            	?>
                                             <option value="<?php echo  $tempcallcenter['id'] ;?>"><?php echo  $tempcallcenter['name'] ;?></option> 
                                             <?php } }?>
                                            </select>   
							
                            </div>
                            
                        </div>
                        
                    </div>
                
                
                <div class="row">
                	<div class="power_btn">
                    	<div class="back_btn">
                        	<div class="input-group select_num_box blue_btn">
                            	<span class="input-group-addon"><i class="fa fa-arrow-left" aria-hidden="true"></i></span>
                            	<a href="">Back</a>
                                 
                            </div>
                        </div>
                        
                        <div class="next_btn">
                        	<div class="input-group select_num_box green_btn">
                            	<button id="next" type="button" class="btn" style="background: none; width: 100%">Next</button>
                            	<span class="input-group-addon"><i class="fa fa-arrow-right" aria-hidden="true"></i></span>
                            </div>
                        </div>
                        	Powerd by<br>
                            <h6>BASTION & FLOWE</h6>
                            digital integration
                        </div>
                </div>
               </form>
                </div>
            </div>
        </div>
    	
</section>
