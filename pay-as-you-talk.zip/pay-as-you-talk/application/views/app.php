<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class App extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_model');
		$this->load->model('client_model');
		$this->load->model('callcenter_model');
		$this->load->library('session');
	}
	
	 
	public function index()
	{
		redirect('app/dashboard');
	}
    public function login()
	{	
		$userdata = array(
				'logged_in'  => FALSE,
				'logged_user'     => ""
		);
		$this->session->set_userdata($userdata);
		
		$this->load->view('header');
		$this->load->view('login');
		$this->load->view('footer');
	}
	
	public function checkLoggedIn(){
		if($this->session->userdata('logged_in') != TRUE){
			redirect('app/login');
		}
		
	} 
	public function auth()
	{
		// user_level=2 means normal user and 1 means admin user
		$userlevel = 2;
		$client_id = null;
		if(!empty($_POST) && isset($_POST['username']) && isset($_POST['password'])){
			 $userdata = $this->user_model->getUser($_POST['username'] ,$_POST['password']);
			 $validuser = false; 
			 if(!empty($userdata)){
			 		$userlevel = $userdata[0]['user_level'];
			 		$client_id = $userdata[0]['client_id'];
			 	    $validuser= true;
			 	}
			 if($validuser){
			//if($_POST['username'] == 'admin' && $_POST['password']){
				$userdata = array(
						'logged_in'  => TRUE,
						'logged_user'     => $_POST['username'],
						'user_level' =>$userlevel,
						'client_id' =>$client_id
				);
				$this->session->set_userdata($userdata);	
				if($userlevel==1){
					redirect('app/users');
				}else{
					redirect('app/dashboard');
				} 
				
			}else{
				redirect('app/login?reason=unauthorised');
			}
		}else {
			redirect('app/login');
		}
	}
	
	public function dashboard()
	{ 
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('dashboard');
		$this->load->view('footer');
	} 
	public function selectprovinces()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('select-provinces');
		$this->load->view('footer');
	}
	public function summary()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('summary');
		$this->load->view('footer');
	}
	public function sendotp($mobile)
	{
		$data = array();
		
		$mobile='9978811857';
		$date = '2015-02-27+12:15:00';
		$url = "http://online.bastionflowe.com/interact/interact_sms_api.php?api_key=GRNHolMg7NLA1NA1qX13KFAZ9jESFw&ref=interactref&to_number=".$mobile."&msg=this+is+the+meesage&date=".$date;
		$curl = curl_init($url);
		
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		
		curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
		
		curl_setopt($curl, CURLOPT_POST, true);
		
		curl_setopt($curl, CURLOPT_VERBOSE, true);
		
		return curl_exec($curl);
		
	}
	public function otp()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$generatedotp = $this->sendotp('+919978811857');
		$data['mobile'] = '+91******1857';
		$data['generatedotp'] = md5($generatedotp);
		$this->load->view('otp',$data);
		$this->load->view('footer');
	}
	
	public function location()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('specific-location');
		$this->load->view('footer');
	}
	public function numberofagents()
	{
		$this->checkLoggedIn();
		$this->load->view('header');

		
		$data['callcenter'] = $this->input->post('callcenter');
	
		$this->load->view('confiugration',$data);
		$this->load->view('footer');
	}
	public function selecttarget()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
	
	
		$data['callcenter'] = $this->input->post('callcenter');
		$data['agents'] = $this->input->post('agents');
		$this->load->view('select-target',$data);
		$this->load->view('footer');
	}
	public function newcampaign()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$data['callcenters'] = $this->callcenter_model->getClientCallcenters($this->session->userdata('client_id'));
		$this->load->view('select-data',$data);
		$this->load->view('footer');
	}
	public function history()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('complete');
		$this->load->view('footer');
	}
	public function results()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('complete');
		$this->load->view('footer');
	}
	public function result1()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('result-1');
		$this->load->view('footer');
	}
	public function results2()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('result-2');
		$this->load->view('footer');
	}
	public function results3()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('result-3');
		$this->load->view('footer');
	}
	public function helps()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('complete');
		$this->load->view('footer');
	}
	public function users()
	{
		$this->checkLoggedIn();
		$data['records'] = $this->user_model->getUsers();
		
		$this->load->view('header');		
		$this->load->view('users',$data);
		$this->load->view('footer');
	}
	public function adduser()
	{
		$this->checkLoggedIn();
		$data['clients'] = $this->client_model->getClients();
		$data['callcenters'] = $this->callcenter_model->getCallcenter();
		$this->load->view('header');
		$this->load->view('adduser',$data);
		$this->load->view('footer');
	}
	public function edituser()
	{
		$this->checkLoggedIn();
		
		$array =  $this->user_model->getUserByID($_GET['id']);
		if(!empty($array)){
			$data['record'] = $this->user_model->getUserByID($_GET['id'])[0];
			$data['clients'] = $this->client_model->getClients();
			$data['callcenters'] = $this->callcenter_model->getCallcenter();
			
			$usercallcentersDB = $this->callcenter_model->getUserCallcenters($_GET['id']);
			$tempcallcenters= array();
			foreach ($usercallcentersDB as $ccc){
				array_push($tempcallcenters, $ccc['callcenter_id']);
			}
			$data['usercenters'] = $tempcallcenters;
		}
		$this->load->view('header');
		$this->load->view('edituser',$data);
		$this->load->view('footer');
	}
	public function deleteUser()
	{
		$this->checkLoggedIn();
		$result = $this->user_model->deleteUser($this->input->post('id'));
		$return = array("success"=>$result);
	    echo json_encode($return);
	}
	public function updateuser()
	{
		$this->checkLoggedIn();
	    $result =   $this->user_model->updateUser($this->input->post('id'), $this->input->post('password'),$this->input->post('firstname'),$this->input->post('surname'),
				$this->input->post('contact'),$this->input->post('client'),$this->input->post('callcenter'),
	    		$this->input->post('userlevel')
		);
	    redirect('app/users');
		//$return = array("success"=>$result);
	    //echo json_encode($return);
		
	}
	public function insertuser()
	{
		$this->checkLoggedIn();
		ini_set('display_errors', 1);
		error_reporting(E_ALL);
		$array =  $this->user_model->getUserByUserName($this->input->post('username'));
		$return = array();
		if(!empty($array)){
		     $return = array("success"=>false,"message"=>"username aleady exists.");
		}else{
			$result =   $this->user_model->insertUser($this->input->post('username'), $this->input->post('password'),$this->input->post('firstname'),$this->input->post('surname'),
					$this->input->post('contact'),$this->input->post('client'),$this->input->post('callcenter'),
					$this->input->post('userlevel')
					);
		
		}
		
		redirect('app/users');
		
	
	}
	public function clients()
	{
		$this->checkLoggedIn();
		$data['records'] = $this->client_model->getClients();
		$this->load->view('header');
		$this->load->view('clients',$data);
		$this->load->view('footer');
	}
	public function addclient()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$data['callcenters'] = $this->callcenter_model->getCallcenter();
		$this->load->view('addclient',$data);
		$this->load->view('footer');
	}
	public function editclient()
	{
		$this->checkLoggedIn();
	
		$array =  $this->client_model->getClientByID($_GET['id']);
		if(!empty($array)){
			$data['record'] = $this->client_model->getClientByID($_GET['id'])[0];
			$data['callcenters'] = $this->callcenter_model->getCallcenter();
			
			$clientcallcentersDB = $this->callcenter_model->getClientCallcenters($_GET['id']);
			$tempclientcallcenters= array();
			foreach ($clientcallcentersDB as $ccc){
				array_push($tempclientcallcenters, $ccc['callcenter_id']); 
			}
			$data['clientcenters'] = $tempclientcallcenters;
			//print_r($tempclientcallcenters);
			//print_r($data['callcenters']);
		}
	
		$this->load->view('header');
		$this->load->view('editclient',$data);
		$this->load->view('footer');
	}
	public function updateclient()
	{
		$this->checkLoggedIn();
		 
		 $destinationpath = '';
		 if(isset($_FILES['file']) && isset($_FILES['file']['name']) && !empty($_FILES['file']['name']))  {
		 	$folder = 'uploads/';
			$filepath= $_FILES['file']['tmp_name'];
			$filename= $_FILES['file']['name'];
			$destinationpath = $folder.$filename;
			move_uploaded_file($filepath, $destinationpath);
		}else{
			$destinationpath= $this->input->post('apifile');
		} 
		 $result =   $this->client_model->updateclient($this->input->post('id'), $this->input->post('clientname'),$this->input->post('callcenter')
		 		,$this->input->post('address'),$destinationpath

		 );	
		 redirect('app/clients');
		
	
	}
	public function deleteClient()
	{
		$this->checkLoggedIn();
		$result = $this->client_model->deleteClient($this->input->post('id'));
		$return = array("success"=>$result);
		echo json_encode($return);
	}
	
	public function insertClient()
	{
		$this->checkLoggedIn();
		$destinationpath = '';
		if(isset($_FILES['file']) && isset($_FILES['file']['name']) && !empty($_FILES['file']['name']))  {
			$folder = 'uploads/';
			$filepath= $_FILES['file']['tmp_name'];
			$filename= $_FILES['file']['name'];
			$destinationpath = $folder.$filename;
			move_uploaded_file($filepath, $destinationpath);
		}
	
		$result =   $this->client_model->insertClient($this->input->post('clientname'), $this->input->post('callcenter'),
				$this->input->post('address'),$destinationpath);
	
	       redirect('app/clients');
	
	}
	
	public function logout()
	{
		
		$userdata = array(
				'logged_in'  => FALSE,
				'logged_user'     => ""
		);
		$this->session->set_userdata($userdata);
		$this->load->view('header');
		$this->load->view('login');
		$this->load->view('footer');
	}
	public function callcenters()
	{
		$this->checkLoggedIn();
		$data['records'] = $this->callcenter_model->getCallcenter();
		$this->load->view('header');
		$this->load->view('callcenters',$data);
		$this->load->view('footer');
	}
	public function addcallcenter()
	{
		$this->checkLoggedIn();
		$this->load->view('header');
		$this->load->view('addcallcenter');
		$this->load->view('footer');
	}
	public function insertCallcenter()
	{
		$this->checkLoggedIn();
		
	
		$result =   $this->callcenter_model->insertCallcenter($this->input->post('name'), $this->input->post('description'),
				$this->input->post('url'));
	
		$return = array("success"=>$result);
		echo json_encode($return);
	
	}
	public function editcallcenter()
	{
		$this->checkLoggedIn();
	
		$array =  $this->callcenter_model->getCallcenterByID($_GET['id']);
		if(!empty($array)){
			$data['record'] = $this->callcenter_model->getCallcenterByID($_GET['id'])[0];
		}
		$this->load->view('header');
		$this->load->view('editcallcenter',$data);
		$this->load->view('footer');
	}
	public function updateCallcenter()
	{
		$this->checkLoggedIn();
	    $result =   $this->callcenter_model->updateCallcenter($this->input->post('id'), $this->input->post('name'),$this->input->post('description'),$this->input->post('url')
		);
		$return = array("success"=>$result);
	    echo json_encode($return);
		
	}
  public function deleteCallCenter()
	{
		$this->checkLoggedIn();
		$result = $this->callcenter_model->deleteCallCenter($this->input->post('id'));
		$return = array("success"=>$result);
		echo json_encode($return);
	}
	public function maptest()
	{
		$this->load->view('maptest');
	}
}