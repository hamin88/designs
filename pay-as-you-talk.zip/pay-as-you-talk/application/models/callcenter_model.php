<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class callcenter_model extends CI_Model {
    
     public function getCallcenter()
     {
     	$sql = "select * from callcenters";
     	$query = $this->db->query($sql);
     	return $query->result_array();
     } 
     public function getCallcenterByID($id)
     {
     	$data = array($id);
     	$sql = "select * from callcenters where id = ? ";
     	$query = $this->db->query($sql, $data);
     	return $query->result_array();
     }
     public function getClientCallcenters($cid)
     {
     	$data = array($cid);
     	$sql = "select callcenters.id, callcenters.name, client_callcenter.* from client_callcenter LEFT JOIN callcenters 
     			ON client_callcenter.callcenter_id = callcenters.id 
     			where client_callcenter.client_id = ? ";
     	$query = $this->db->query($sql, $data);
     	return $query->result_array();
     }
    public function getUserCallcenters($uid)
     {
     	$data = array($uid);
     	$sql = "select * from user_callcenter where user_id = ? ";
     	$query = $this->db->query($sql, $data);
     	return $query->result_array();
     }
     public function updateCallcenter($id,$name,$description,$url,$destinationpath,$filedescription)
     {
     	$data = array();
     	if(empty($destinationpath)){
     		$data = array('name'=> $name,'description'=> $description,'url'=> $url,
     				'api_file_desc'=> $filedescription,'per_sec_billing_rate'=> $billing); 
     	} else{
     		$data = array('name'=> $name,'description'=> $description,'url'=> $url,'api_file'=> $destinationpath,
     				'api_file_desc'=> $filedescription,'per_sec_billing_rate'=> $billing); 
     	}
     	
     	return  $this->db->where('id', $id)->update('callcenters', $data);
     	
     }
     public function deleteCallCenter($id)
     {
     	return  $this->db->where('id', $id)->delete('callcenters');
     	 
     }
     public function insertCallcenter($name,$description,$url,$destinationpath,$filedescription)
     {
     	$data = array('name'=> $name,'description'=> $description,'url'=> $url,
     			'api_file'=> $destinationpath,'api_file_desc'=> $filedescription );
     	$this->db->insert('callcenters', $data);
		$id = $this->db->insert_id();
		return (isset($id)) ? TRUE : FALSE;
     
     }
            
       
}