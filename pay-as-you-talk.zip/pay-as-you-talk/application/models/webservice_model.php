<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class webservice_model extends CI_Model {
    
           
	public function sendotp($mobile,$otp,$date)
	{
		$date = '2015-02-27+12:15:00';
		$msg = "Generated+OTP+is+".$otp;
		$data = array();
		$url = "http://online.bastionflowe.com/interact/interact_sms_api.php?api_key=GRNHolMg7NLA1NA1qX13KFAZ9jESFw&ref=interactref&to_number=".$mobile."&msg=".$msg."&date=".$date;
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		
		curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
		
		curl_setopt($curl, CURLOPT_POST, true);
		
		curl_setopt($curl, CURLOPT_VERBOSE, true);
		
		return curl_exec($curl);
	}
	
	
	public function getcount($areatype)
	{
		$data = array(
	
				'call' =>'count',
				'areatype'=>$areatype
		);
	
		$curl = curl_init('http://online.bastionflowe.com/payt_api/');
	
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	
		curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
	
		curl_setopt($curl, CURLOPT_POST, true);
	
		curl_setopt($curl, CURLOPT_VERBOSE, true);
	
		$logfh = fopen("log.txt", 'a+');
	
		curl_setopt($curl, CURLOPT_STDERR, $logfh);
	
		echo curl_exec($curl);
	}
	
	public function createcampaign($data)
	{
		
    $curl = curl_init('http://online.bastionflowe.com/payt_api/');

    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));

    curl_setopt($curl, CURLOPT_POST, true);

    curl_setopt($curl, CURLOPT_VERBOSE, true);

    $logfh = fopen("log.txt", 'a+');

    curl_setopt($curl, CURLOPT_STDERR, $logfh);

    return  curl_exec($curl);
	}
       
}