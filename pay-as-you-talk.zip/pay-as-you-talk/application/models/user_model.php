<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class user_model extends CI_Model {
    
     public function getUsers()
     {
     	$sql = "SELECT users.*, clients.client_name , user_type.name as userlevelname FROM users 
LEFT JOIN user_type  ON user_type.value=users.user_level
LEFT JOIN clients ON clients.id=users.client_id ";
     	$query = $this->db->query($sql);
     	return $query->result_array();
     } 
     public function getUser($username,$password)
     {
     	$data = array($username, $password);
		$sql = "select u.*, ut.name as userlevelname  from users u, user_type ut where u.user_level = ut.value				   
				AND  u.username = ? AND u.password =? ";
		$query = $this->db->query($sql, $data);
		return $query->result_array();
     }
     public function getUserByID($id)
     {
     	$data = array($id);
     	$sql = "select * from users where id = ? ";
     	$query = $this->db->query($sql, $data);
     	return $query->result_array();
     }
     public function getUserByUserName($username)
     {
     	$data = array($username);
     	$sql = "select *  from users where username = ?";
     	$query = $this->db->query($sql, $data);
     	return $query->result_array();
     }
     
     public function updateUser($id,$password,$firstname,$surname,$contact,$linktoclient,$linktocallcenters,$userlevel)
     {
     	$this->db->where('user_id', $id)->delete('user_callcenter');
     	if(!empty($linktocallcenters)){
     		foreach ($linktocallcenters as $callcenter){
     			$callcenterdata = array('user_id'=>$id,'callcenter_id'=>$callcenter);
     			$this->db->insert('user_callcenter', $callcenterdata);
     		}
     	}
     	
     	$data = array('password'=> $password,'first_name'=> $firstname,'surname'=> $surname,'contact'=> $contact,'client_id'=> $linktoclient,
     	'user_level'=>$userlevel		
     	);     
     	return  $this->db->where('id', $id)->update('users', $data);
     	
     }
     public function deleteUser($id)
     {
     	$this->db->where('user_id', $id)->delete('user_callcenter');
     	return  $this->db->where('id', $id)->delete('users');
     
     }
     public function insertUser($username,$password,$firstname,$surname,$contact,$client,$callcenters,$userlevel)
     {
     	 //ini_set('display_errors', 1);
     	 //error_reporting(E_ALL);
     	$data = array('username'=> $username,'password'=>  $password,'first_name'=> $firstname,'surname'=> $surname,
     			'contact'=>$contact,'client_id'=>$client,'user_level'=>$userlevel
     	);
     	$this->db->insert('users', $data);
		$id = $this->db->insert_id();
		if (isset($id)){
			foreach ($callcenters as $callcenter){
				$callcenterdata = array('user_id'=>$id,'callcenter_id'=>$callcenter);
				$this->db->insert('user_callcenter', $callcenterdata);
			}
		}
		
		return (isset($id)) ? TRUE : FALSE;
     }
     
       
       
}