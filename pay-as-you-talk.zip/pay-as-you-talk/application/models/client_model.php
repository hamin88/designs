<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class client_model extends CI_Model {
    
     public function getClients()
     {
     	$sql = "select * from clients";
     	$query = $this->db->query($sql);
     	return $query->result_array();
     } 
     public function getClientByID($id)
     {
     	$data = array($id);
     	$sql = "select * from clients where id = ? ";
     	$query = $this->db->query($sql, $data);
     	return $query->result_array();
     }
     
     public function updateclient($id,$clientname,$callcenters,$address,$billing)
     {
     	
     	$this->db->where('client_id', $id)->delete('client_callcenter');
     	foreach ($callcenters as $callcenter){
     		$callcenterdata = array('client_id'=>$id,'callcenter_id'=>$callcenter);
     		$this->db->insert('client_callcenter', $callcenterdata);
     	}
     	$data = array('client_name'=>$clientname,'address'=> $address,'per_sec_billing_rate'=> $billing
     			
     	);   
     	return  $this->db->where('id', $id)->update('clients', $data);
     	
     }
     public function deleteClient($id)
     {
     	 $this->db->where('client_id', $id)->delete('client_callcenter');
     	 $data = array($id);
     	 $sql = "delete from user_callcenter where user_id in (select id from users where client_id = ? )";
     	 $query = $this->db->query($sql, $data);
     	 
     	 $this->db->where('client_id', $id)->delete('users');
     	return  $this->db->where('id', $id)->delete('clients');
     	 
     }
     public function insertClient($clientname,$callcenters,$address,$billing)
     {
     	
     	$data = array('client_name'=> $clientname,'address'=> $address,'per_sec_billing_rate'=> $billing
     	);
     	$this->db->insert('clients', $data);
		$id = $this->db->insert_id();
		if (isset($id)){
			foreach ($callcenters as $callcenter){
				$callcenterdata = array('client_id'=>$id,'callcenter_id'=>$callcenter);
				$this->db->insert('client_callcenter', $callcenterdata);
			}
		}
		
		return (isset($id)) ? TRUE : FALSE;
     
     }
            
       
}