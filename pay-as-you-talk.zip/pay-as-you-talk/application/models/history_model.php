<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class history_model extends CI_Model {
    
	
	public function getClientHistoryCount($cid)
	{
			
		$data = array($cid);
		$sql = "select count(*) as cnt from history where client_id = ? ";
		$query = $this->db->query($sql, $data);
		return $query->result_array();
	}
	public function getClientHistory($cid,$page,$perpage)
	{
		 
     	$data = array($cid);
     	$sql = "select * from history where client_id = ? ";
     	$sql.= " LIMIT ".(2*($page-1))." , ".$perpage."";
     	$query = $this->db->query($sql, $data);
     	return $query->result_array();
	}
	
	public function getClientCampaignHistory($cid)
	{
			
		$data = array($cid);
		$sql = "SELECT campaign_id, total_sec, total_amt, MIN( call_date_date ) AS min_call_date, MAX( call_date_date ) AS max_call_date
			FROM ( SELECT campaign_id, SUM( length_in_sec ) AS total_sec, SUM( length_in_sec ) *250 AS total_amt, call_date, 
				STR_TO_DATE( '2016-07-21 02:34:19',  '%Y-%m-%d %h:%i:%s' ) AS call_date_date FROM  `history`  where client_id = ? 
				GROUP BY campaign_id ) AS temp";
		$query = $this->db->query($sql, $data);
		return $query->result_array();
	}
	
	
	public function getClientHistoryRecord($cid,$calldate)
	{
			
		$data = array($cid,$calldate);
		$sql = "select * from history where client_id = ? and call_date=? ";
		$query = $this->db->query($sql, $data);
		return $query->result_array();
	}
	
	public function getClientHistoryRecordWithLeadId($cid,$leadid)
	{
			
		$data = array($cid,$leadid);
		$sql = "select * from history where client_id = ? and lead_id=? ";
		$query = $this->db->query($sql, $data);
		return $query->result_array();
	}
	public function insertOrUpdateRecord($record)
	{
		
		$previousRecords = $this->getClientHistoryRecordWithLeadId($record['client_id'],$record['lead_id']);
		if(!empty($previousRecords)){
			return $this->db->where('lead_id', $record['lead_id'])->update('history', $record);
		}else{
			$this->db->insert('history', $record);
			$id = $this->db->insert_id();
			return (isset($id)) ? TRUE : FALSE;
		}
     	
	}
	public function deleteOldRecords($cid)
	{		
		
		return $this->db->where('client_id', $cid)->delete('history');
	}
	public function getActivecampaigns($cid)
	{
			
		$data = array($cid);
     	$sql = "select  count(distinct campaign_id) as cnt from history where client_id = ? ";
     	$query = $this->db->query($sql, $data);
     	return $query->result_array();
	}
	public function getMonthcampaigns($cid,$yearmonth)
	{
			
		$data = array($cid);
		$sql = "select  count(distinct campaign_id) as cnt from history where client_id = ? and call_date LIKE  '".$yearmonth."%'";
		$query = $this->db->query($sql, $data);
		return $query->result_array();
	}
	public function getUsage($cid,$yearmonth)
	{
		$data = array($cid);
		$sql = "SELECT  sum(length_in_sec) as usages FROM  `history` WHERE client_id = ? and call_date LIKE  '".$yearmonth."%'";
		$query = $this->db->query($sql,$data);
		return $query->result_array();
	}
	
}