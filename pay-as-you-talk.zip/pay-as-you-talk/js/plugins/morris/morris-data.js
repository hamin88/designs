// Morris.js Charts sample data for SB Admin template

$(function() {
var months = ["Jan", "Feb", "Mar", "April", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec"];

    // Area Chart
    Morris.Area({
        element: 'morris-area-chart',
        data: [{
            period: '2010-04', 			usage: "<?php echo isset($usage) && isset($usage[0]) $usage[0]['2016-08'] ;?>"
        }, {            period: '2010-05',            usage: "<?php echo isset($usage) && isset($usage[0]) $usage[0]['2016-08'] ;?>"        }, {            period: '2010-06',            usage: "<?php echo isset($usage) && isset($usage[0]) $usage[0]['2016-08'] ;?>"        }, {
            period: '2010-07',            usage: "<?php echo isset($usage) && isset($usage[0]) $usage[0]['2016-08'] ;?>"
        }],
        xkey: 'period',
        ykeys: ['usage'],
        labels: ['Usage'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true,
		xLabels : "month",
		xLabelFormat : function(x) { 
             var month = months[x.getMonth()];
              return month;
        }
		 

    });

     

     

     

});
