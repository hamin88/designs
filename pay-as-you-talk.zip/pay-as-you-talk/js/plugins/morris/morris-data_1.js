// Morris.js Charts sample data for SB Admin template

$(function() {
var months = ["Jan", "Feb", "Mar", "April", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec"];

    // Area Chart
    Morris.Area({
        element: 'morris-area-chart',
        data: [{
            period: '2010-04',
 			iphone: 54,
			ipad: null
            
            
        }, {
            period: '2010-05',
            iphone: 38,
            ipad: null
            
        }, {
            period: '2010-06',
            iphone: 72,
            ipad: null
        }, {
            period: '2010-07',
            iphone: 58,
            ipad: 40
        }],
        xkey: 'period',
        ykeys: ['iphone', 'ipad', 'itouch'],
        labels: ['iPhone', 'iPad', 'iPod Touch'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true,
		xLabels : "month",
		xLabelFormat : function(x) { 
             var month = months[x.getMonth()];
              return month;
        }
		 

    });

     

     

     

});
